"""Live full-duplex GATT soak on the already-installed image; no reflashing.

Board sends are driven by an owned SD NSH script to avoid serial round-trip
pacing. PC writes run independently using four receive credits. Notifications
are checked byte-for-byte; board receives are checked by the existing FNV32
CLI. First failure stops the test without reset or automatic BLE reconnection.
"""
from pathlib import Path
import argparse
import asyncio
import hashlib
from http.client import HTTPConnection
import io
import json
import re
import secrets
import struct
import sys
import time
import urllib.parse
import zlib
import serial
from bleak import BleakAdapter, BleakClient, BleakScanner
from bleak.exc import BleakGATTProtocolError
from winrt.windows.devices.radios import Radio, RadioKind, RadioState

out = Path(__file__).resolve().parent
root = out.parents[1]
previous = root / 'output/c6-ble-coexist-20261108'
sys.path.insert(0, str(root / 'project/tools'))
from music_device_console import Console

parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True)
parser.add_argument('--seconds', type=int, default=900)
parser.add_argument('--minimum-packets', type=int, default=65536)
parser.add_argument('--pilot', type=int, default=200)
args = parser.parse_args()
assert re.fullmatch('[a-z0-9-]+', args.label)
record = out / (args.label + '.json')
assert not record.exists()
identity = json.loads((previous / 'board-candidate/firmware/BLE-IDENTITY.json').read_text())
nonce = secrets.token_bytes(4)
directory = 'c6duplex-' + nonce.hex()
state = {'passed': False, 'label': args.label, 'nonce': nonce.hex(),
         'method': 'independent PC writer and board NSH script producer; encrypted GATT',
         'sizes': {'pc_to_board': 244, 'board_to_pc': 20},
         'rx_queue_slots': 4, 'flow_control': 'ATT write responses; retry only explicit queue-full rejection',
         'pc_queue_full_retries': 0, 'pc_written': 0, 'board_verified': 0,
         'pc_notified_verified': 0, 'board_submitted': 0,
         'wifi': {'success': 0, 'failures': [], 'max_ms': 0},
         'c6_uart': {'bytes': 0, 'events': [], 'faults': [], 'resets': 0},
         'errors': [], 'health_samples': [], 'phases': [], 'disconnects': 0,
         'automatic_reconnects': 0, 'board_resets_requested': 0,
         'owned_sd_directory': '/sdcard/' + directory,
         'firmware_changed': False}
stop = asyncio.Event()
writer_stop = asyncio.Event()
failure = asyncio.Event()
console = None
wire = None
uart = None
tasks = []
collecting = False
script_running = False
phase_end = None
phase_start = None
phase_frame_start = 0
phase_frame_target = 0
progress_at = 0
address = None
token = None
created = False
owned_scripts = []
up_digest = hashlib.sha256()
down_digest = hashlib.sha256()
last_ble_progress = 0


def save():
    state['pc_to_board_bytes_verified'] = state['board_verified'] * 244
    state['board_to_pc_bytes_verified'] = state['pc_notified_verified'] * 20
    state['upstream_verified_stream_sha256'] = up_digest.hexdigest()
    state['downstream_verified_stream_sha256'] = down_digest.hexdigest()
    record.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')


def fail(message):
    if message not in state['errors']:
        state['errors'].append(message)
        print('TEST_FAILURE', message[:200], flush=True)
    failure.set()
    save()


def frame(sequence, length, direction):
    header = nonce + struct.pack('<I', sequence) + bytes([direction])
    body = header + bytes((sequence * 37 + i * 13 + direction) & 255 for i in range(length - len(header) - 4))
    return body + struct.pack('<I', zlib.crc32(body))


def fnv(data):
    value = 2166136261
    for byte in data:
        value = ((value ^ byte) * 16777619) & 0xffffffff
    return f'{value:08x}'


def http(method, path, body=None, auth=False):
    connection = HTTPConnection(address, 8080, timeout=15)
    headers = {}
    if auth:
        headers['Authorization'] = 'Bearer ' + token
    if isinstance(body, dict):
        headers['Content-Type'] = 'application/json'
        body = json.dumps(body)
    elif isinstance(body, bytes):
        headers['Content-Length'] = str(len(body))
        body = io.BytesIO(body)
    try:
        connection.request(method, path, body, headers)
        response = connection.getresponse()
        data = response.read()
        assert response.status == 200, f'HTTP {method} status {response.status}'
        length = response.getheader('Content-Length')
        assert length is None or int(length) == len(data)
        return data
    finally:
        connection.close()


async def command(text, timeout=10):
    assert not collecting
    return await asyncio.to_thread(console.command, text, timeout)


def notification(characteristic, data):
    global last_ble_progress
    sequence = state['pc_notified_verified']
    expected = frame(sequence, 20, 0xd0)
    if bytes(data) != expected:
        fail(f'notification mismatch at sequence {sequence}; received_bytes={len(data)}')
        return
    down_digest.update(data)
    state['pc_notified_verified'] += 1
    last_ble_progress = time.monotonic()


def parse_line(line):
    global phase_end, last_ble_progress
    if re.search(r'panic|Assertion failed|access fault|Unhandled exception|boot:|ESP-ROM:', line, re.I):
        fail('P4 runtime fault/reset marker: ' + line[:200])
    matched = re.search(r'BLE_CHANNEL_DATA bytes=(\d+) fnv32=([0-9a-fA-F]{8})', line)
    if matched:
        expected = frame(state['board_verified'], 244, 0xa0)
        if int(matched[1]) != 244 or matched[2].lower() != fnv(expected):
            fail(f'board RX checksum/order mismatch at sequence {state["board_verified"]}')
        else:
            up_digest.update(expected)
            state['board_verified'] += 1
            last_ble_progress = time.monotonic()
    matched = re.search(r'c6ble channel (send|receive) result=(-?\d+)', line)
    if matched:
        op, result = matched[1], int(matched[2])
        if op == 'send':
            if result:
                fail(f'board send returned {result}')
            else:
                state['board_submitted'] += 1
        elif result not in (0, -11):
            fail(f'board receive returned {result}')
    if line.startswith('BLE_CHANNEL '):
        fields = dict(re.findall(r'(\w+)=(-?\d+)', line))
        if not all(fields.get(key) == value for key, value in
                   [('connected', '1'), ('encrypted', '1'), ('notify', '1'), ('epoch', str(state['epoch']))]):
            fail('board BLE connection/encryption/epoch changed')
    if line.startswith('c6: counter_retries='):
        fields = {key: int(value) for key, value in re.findall(r'(\w+)=(-?\d+)', line)}
        fields['elapsed'] = round(time.monotonic() - phase_start, 3) if phase_start else 0
        state['health_samples'].append(fields)
        if any(fields.get(key) != 0 for key in ('counter_exhausted', 'hci_tx_errors', 'link_error')):
            fail('shared SDIO/HCI health counter reported an error')
    if re.search(r'c6probe: link_error=(-?[1-9]\d*)', line):
        fail('C6 shared link error')
    if line.strip() == 'DUPLEX_PHASE_COMPLETE':
        phase_end = time.monotonic()


async def board_reader():
    global collecting
    buffer = bytearray()
    collecting = True
    try:
        while not stop.is_set():
            data = console.serial.read(console.serial.in_waiting) if console.serial.in_waiting else b''
            if data:
                if script_running and b'nsh> ' in data:
                    # The producer's receipts are on SD; its prompt signals EOF.
                    globals()['phase_end'] = time.monotonic()
                buffer.extend(data)
                while b'\n' in buffer:
                    raw, _, buffer = buffer.partition(b'\n')
                    line = raw.decode(errors='replace').replace('\r', '')
                    # Keep only synthetic test receipts and health lines.
                    if re.search(r'BLE_CHANNEL|c6ble channel|^c6:|^c6probe:|DUPLEX_|panic|Assertion|access fault|Unhandled exception', line, re.I):
                        wire.write(line + '\n')
                        wire.flush()
                    parse_line(line)
            if len(buffer) > 4096:
                buffer.clear()
            await asyncio.sleep(.002)
    finally:
        collecting = False


async def c6_reader():
    buffer = bytearray()
    accepted = re.compile(r'ESP-ROM|rst:|ELF file SHA256|BLE controller capacity|panic|Guru Meditation|assert|Backtrace|watchdog|brownout|memory allocation failed|VHCI.*timeout|sdio.*error|WIFI_TX_FIRST_FAIL', re.I)
    faults = re.compile(r'panic|Guru Meditation|assert|Backtrace|watchdog|brownout|memory allocation failed|VHCI.*timeout|sdio.*error|WIFI_TX_FIRST_FAIL', re.I)
    with (out / (args.label + '-c6.log')).open('w', encoding='utf-8') as log:
        while not stop.is_set():
            data = uart.read(uart.in_waiting) if uart.in_waiting else b''
            state['c6_uart']['bytes'] += len(data)
            buffer.extend(data)
            while b'\n' in buffer:
                raw, _, buffer = buffer.partition(b'\n')
                line = re.sub(r'\x1b\[[0-9;]*m', '', raw.decode(errors='replace')).strip()
                if accepted.search(line) and not re.search(r'password|api.?key|authorization|hexlog|pb bytes', line, re.I):
                    log.write(line + '\n'); log.flush()
                    state['c6_uart']['events'].append(line)
                    if re.search(r'ESP-ROM|rst:', line):
                        state['c6_uart']['resets'] += 1
                        fail('unexpected C6 boot/reset marker')
                    if faults.search(line):
                        state['c6_uart']['faults'].append(line)
                        fail('C6 UART fault marker: ' + line[:150])
            if len(buffer) > 4096:
                buffer.clear()
            await asyncio.sleep(.01)


async def pc_writer(client):
    try:
        while not stop.is_set() and not writer_stop.is_set() and not failure.is_set():
            if stop.is_set() or writer_stop.is_set() or failure.is_set():
                break
            data = frame(state['pc_written'], 244, 0xa0)
            try:
                await asyncio.wait_for(client.write_gatt_char('fe295b09-ba85-4b80-aec3-095121e8ae2f', data, response=True), 10)
            except BleakGATTProtocolError as error:
                if error.args[0] != 0x11:
                    raise
                state['pc_queue_full_retries'] += 1
                await asyncio.sleep(.01)
                continue
            state['pc_written'] += 1
    except Exception as error:
        fail('PC GATT writer: ' + type(error).__name__ + ': ' + str(error)[:180])


async def wifi_load():
    while not stop.is_set() and not failure.is_set():
        started = time.monotonic()
        try:
            assert await asyncio.to_thread(http, 'GET', '/')
            state['wifi']['success'] += 1
            state['wifi']['max_ms'] = max(state['wifi']['max_ms'], round((time.monotonic()-started)*1000, 1))
        except Exception as error:
            state['wifi']['failures'].append(type(error).__name__ + ': ' + str(error)[:150])
            fail('Concurrent Wi-Fi request failed')
        await asyncio.sleep(.1)


async def phase(start, count, delay):
    global phase_start, phase_end, script_running, phase_frame_start, phase_frame_target
    filename = 'stream-' + str(start) + '.sh'
    path = 'sdcard/' + directory + '/' + filename
    parts = ['set +x\n']
    for number in range(start, start + count):
        # Only an empty RX FIFO is benign; a send failure terminates the script.
        parts += ['set +e\n', f'c6ble channel receive {state["epoch"]}\n', 'set -e\n',
                  f'c6ble channel send {state["epoch"]} {frame(number,20,0xd0).hex()}\n']
        if delay:
            parts += [f'usleep {delay}\n']
        if (number-start+1) % 256 == 0:
            parts += ['c6ble channel status\n', 'c6probe stat\n']
    parts += ['echo DUPLEX_PHASE_COMPLETE\n']
    content = ''.join(parts).encode()
    assert all(len(line) < 79 for line in content.splitlines())
    owned_scripts.append(filename)
    await asyncio.to_thread(http, 'PUT', '/api/file?path=' + urllib.parse.quote(path, safe=''), content, True)
    phase_start, phase_end = time.monotonic(), None
    phase_frame_start, phase_frame_target = start, start + count
    script_running = True
    result_name = 'result-' + str(start) + '.log'
    owned_scripts.append(result_name)
    console.serial.write(('sh ' + filename + ' > ' + result_name + '\r').encode()); console.serial.flush()
    last_report = 0
    while phase_end is None and not failure.is_set():
        now = time.monotonic()
        if now - last_report >= 10:
            state['current_phase'] = {'start': start, 'target_packets': count,
                                      'elapsed': round(now-phase_start, 1)}
            save()
            print('DUPLEX_PROGRESS', json.dumps({
                'elapsed': round(now-phase_start,1), 'down_packets': state['pc_notified_verified']-start,
                'up_packets': state['board_verified'], 'wifi': state['wifi']['success'],
                'errors': len(state['errors'])}), flush=True)
            last_report = now
        if now - last_ble_progress > 15:
            fail('No verified BLE progress for 15 seconds')
        if now - phase_start > max(args.seconds*3, 1800):
            fail('Bounded phase deadline exceeded')
        await asyncio.sleep(.05)
    if failure.is_set():
        raise RuntimeError(state['errors'][0])
    script_running = False
    until = time.monotonic() + 10
    while state['pc_notified_verified'] < start + count and time.monotonic() < until:
        await asyncio.sleep(.02)
    assert state['pc_notified_verified'] == start + count
    elapsed = phase_end - phase_start
    receipts = await asyncio.to_thread(http, 'GET', '/api/file?path=' + urllib.parse.quote('sdcard/'+directory+'/'+result_name,safe=''), None, True)
    local = out / (args.label + '-' + result_name)
    local.write_bytes(receipts)
    assert receipts.rstrip().endswith(b'DUPLEX_PHASE_COMPLETE'), 'Producer ended before its completion marker'
    for line in receipts.decode(errors='strict').splitlines():
        parse_line(line)
    assert not failure.is_set(), state['errors']
    assert state['board_submitted'] == start + count
    result = {'start_sequence': start, 'down_packets': count, 'seconds': round(elapsed,3),
              'delay_us': delay, 'up_verified_total': state['board_verified'],
              'wifi_success_total': state['wifi']['success']}
    state['phases'].append(result)
    save()
    return elapsed


async def main():
    global console, wire, uart, address, token, created, last_ble_progress
    radios = []
    client = None
    reader = None
    writer = None
    loop = asyncio.get_running_loop()
    try:
        radios = [(r, r.state) for r in await Radio.get_radios_async() if r.kind == RadioKind.BLUETOOTH]
        assert radios
        state['pc_radios_before'] = [{'name': r.name, 'state': before.name} for r,before in radios]
        for radio, before in radios:
            if before != RadioState.ON:
                await radio.set_state_async(RadioState.ON)
        wire = (out / (args.label + '-board.log')).open('w', encoding='utf-8')
        console = Console(wire); console.serial.dtr = True
        state['identity'] = await command('c6ble identity')
        assert identity['address'] in state['identity'] and identity['name'] in state['identity']
        state['xip'] = await command('desktop xip')
        expected = json.loads((previous / 'board-candidate/EXPECTED-XIP-HASHES.json').read_text())
        assert all(value in state['xip'] for value in expected.values())
        state['transport_before'] = await command('c6probe stat')
        assert 'link_error=0' in state['transport_before'] and 'hci_tx_errors=0' in state['transport_before']
        interfaces = await command('ifconfig')
        address = re.search(r'wlan0[\s\S]*?inet addr:([0-9.]+)', interfaces)[1]
        assert address.startswith('192.168.')
        await command('desktop ui portal')
        secret = io.StringIO(); console.log = secret
        try:
            pair = await command('desktop portal-pair')
            code = re.search(r'PORTAL_PAIR=(\d{6})', pair)[1]
            token = json.loads(await asyncio.to_thread(http, 'POST', '/api/pair', {'code': code}))['token']
            del pair, code
        finally:
            console.log = wire; secret.close()
        space = await command('df')
        sd = re.search(r'(?m)^\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+/sdcard\s*$', space)
        assert sd and int(sd[1])*int(sd[4]) > 40*1024*1024
        await asyncio.to_thread(http, 'POST', '/api/mkdir?path=' + urllib.parse.quote('sdcard/'+directory,safe=''), {}, True)
        created = True
        await command('cd /sdcard/' + directory)
        await command('c6ble mouse start', 25)
        device = None
        adapter = await BleakAdapter.get()
        for attempt in range(3):
            devices = await adapter.get_connected_devices()
            device = next((d for d in devices if d.address.upper() == identity['address']), None)
            if device:
                break
            device = await BleakScanner.find_device_by_filter(
                lambda d,a: d.address.upper() == identity['address'] and a.local_name == identity['name'], timeout=5)
            if device:
                break
        assert device, 'Exact installed identity not discovered'
        def disconnected(disconnected_client):
            if not stop.is_set():
                state['disconnects'] += 1
                fail('BLE disconnected unexpectedly')
        client = BleakClient(device, pair=True, timeout=45, disconnected_callback=disconnected,
                             winrt={'address_type':'random','use_cached_services':False})
        await client.connect()
        info = bytes(await client.read_gatt_char('e86cb6ea-0566-4ea9-b513-1d94e99c9a54', use_cached=False))
        assert info == bytes([1,0,244,0,4,0,3,0])
        await client.start_notify('9fc89159-b5c1-4797-8f7a-0f375f7e8138', notification)
        status = await command('c6ble channel status')
        assert 'connected=1 encrypted=1 notify=1' in status
        assert 'queued=0' in status
        state['epoch'] = int(re.search(r'BLE_CHANNEL .*?epoch=(\d+)',status)[1])
        state['mtu'] = client.mtu_size
        state['channel_before'] = status
        uart = serial.Serial(port=None, baudrate=115200, timeout=0)
        uart.dtr = uart.rts = False; uart.port = 'COM5'; uart.open()
        uart.reset_input_buffer()
        last_ble_progress = time.monotonic()
        reader = asyncio.create_task(board_reader()); tasks.append(reader)
        tasks.append(asyncio.create_task(c6_reader()))
        writer = asyncio.create_task(pc_writer(client)); tasks.append(writer)
        tasks.append(asyncio.create_task(wifi_load()))
        elapsed = await phase(0, args.pilot, 0)
        base = elapsed / args.pilot
        count = max(args.minimum_packets, int(args.seconds/base))
        # Avoid a needless increase in send count when board control is fast:
        # use minimum aggregate traffic and pace it across the chosen duration.
        count = args.minimum_packets
        delay = max(0, int((args.seconds/count-base)*1_000_000))
        state['calibration'] = {'pilot_seconds': elapsed, 'seconds_per_packet': base,
                                'main_packets': count, 'delay_us': delay,
                                'estimated_main_seconds': round(count*(base+delay/1e6),1)}
        save(); print('DUPLEX_CALIBRATED', json.dumps(state['calibration']), flush=True)
        await phase(args.pilot, count, delay)
        # Stop the independent writer, then use a short receive-only script to
        # verify the at-most-four already accepted final packets.
        writer_stop.set(); await writer
        drain = 'set +e\n' + (f'c6ble channel receive {state["epoch"]}\n'*8) + 'echo DUPLEX_DRAIN_COMPLETE\n'
        owned_scripts.append('drain.sh')
        await asyncio.to_thread(http,'PUT','/api/file?path='+urllib.parse.quote('sdcard/'+directory+'/drain.sh',safe=''),drain.encode(),True)
        owned_scripts.append('drain.log')
        console.serial.write(b'sh drain.sh > drain.log\r'); console.serial.flush()
        await asyncio.sleep(2)
        receipts = await asyncio.to_thread(http,'GET','/api/file?path='+urllib.parse.quote('sdcard/'+directory+'/drain.log',safe=''),None,True)
        (out / (args.label+'-drain.log')).write_bytes(receipts)
        assert b'DUPLEX_DRAIN_COMPLETE' in receipts
        for line in receipts.decode().splitlines():
            parse_line(line)
        assert state['board_verified'] == state['pc_written'], (state['board_verified'],state['pc_written'])
        assert not state['errors'] and not state['wifi']['failures']
        state['passed'] = True
    except BaseException as error:
        state['terminal_error'] = type(error).__name__ + ': ' + str(error)[:300]
        if isinstance(error, (KeyboardInterrupt, asyncio.CancelledError)):
            state['interrupted'] = True
        else:
            fail(state['terminal_error'])
    finally:
        stop.set()
        # Removing notify makes any still-running finite producer fail its next
        # send and return to NSH. No reset/reconnect is used to hide a failure.
        if client and client.is_connected:
            try:
                await asyncio.wait_for(client.stop_notify('9fc89159-b5c1-4797-8f7a-0f375f7e8138'),5)
            except Exception as error:
                state['stop_notify_error'] = type(error).__name__
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        if console:
            try:
                await asyncio.sleep(.2)
                # A send can wait up to three seconds for its persistent owner.
                if script_running:
                    await asyncio.to_thread(console.collect, 4)
                state['channel_after'] = await command('c6ble channel status')
                state['transport_after'] = await command('c6probe stat')
                state['network_after'] = await command('c6probe netstat')
                state['hid_diagnostics_after'] = await command('c6ble mouse diagnostics')
                await command('c6ble mouse stop')
                if created:
                    await command('cd /')
                    assert re.fullmatch('c6duplex-[0-9a-f]{8}', directory)
                    for name in owned_scripts:
                        await command('rm /sdcard/'+directory+'/'+name)
                    await command('rmdir /sdcard/'+directory)
                    removed = await command('ls /sdcard/'+directory)
                    state['owned_fixture_removed'] = bool(re.search('no such file|not found|not a directory',removed,re.I))
                await command('desktop ui home')
                state['final_ble'] = await command('c6ble mouse status')
            except Exception as error:
                state['cleanup_error'] = type(error).__name__ + ': ' + str(error)[:200]
                state['passed'] = False
            finally:
                console.close()
        if client:
            try:
                await asyncio.wait_for(client.disconnect(),5)
            except Exception:
                pass
        if uart:
            uart.close()
        if wire:
            wire.close()
        restored = []
        for radio, before in radios:
            if radio.state != before:
                await radio.set_state_async(before)
            restored.append({'name':radio.name,'after':radio.state.name,'restored':radio.state==before})
        state['pc_radios_restored'] = restored
        state['passed'] = state['passed'] and not state['errors'] and all(r['restored'] for r in restored)
        save()
    print('DUPLEX_RESULT', state['passed'], state['pc_to_board_bytes_verified'], state['board_to_pc_bytes_verified'], flush=True)
    if not state['passed']:
        raise SystemExit(1)


asyncio.run(main())
