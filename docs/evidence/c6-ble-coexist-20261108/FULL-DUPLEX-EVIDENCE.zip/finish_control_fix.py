"""Python 3.14 remote_exec fix for this owned, running test controller.

No firmware access or BLE reconnection. Stop producers/probes only AFTER the
finite main pressure phase has ended, then refresh the expired portal session
and retrieve evidence. Pairing code and token stay within the test process.
"""
import __main__ as m
import asyncio
import io
import json
import re
import time

assert m.args.label == 'duplex-sd-receipts'
assert m.phase_frame_start == 200 and m.script_running
assert not m.failure.is_set()
original_http = m.http
controller_loop = m.tasks[0].get_loop()


async def stop_after_pressure():
    assert m.phase_end is not None and m.phase_frame_target == 65736
    m.writer_stop.set()
    await m.tasks[2]
    for task in (m.tasks[0], m.tasks[3]):
        task.cancel()
    await asyncio.gather(m.tasks[0], m.tasks[3], return_exceptions=True)
    m.state['evidence_retrieval_boundary'] = {
        'main_elapsed': m.phase_end-m.phase_start,
        'pc_written': m.state['pc_written'],
        'pc_notified_verified': m.state['pc_notified_verified'],
        'wifi_success': m.state['wifi']['success'],
        'wifi_failures': list(m.state['wifi']['failures']),
        'reason': 'main pressure complete; pause root probes during serialized large evidence download',
    }


def controlled_http(method, path, body=None, auth=False):
    if (auth and method == 'GET' and path.startswith('/api/file?')
            and m.phase_frame_start == 200
            and 'evidence_retrieval_boundary' not in m.state):
        assert m.phase_end is not None
        asyncio.run_coroutine_threadsafe(stop_after_pressure(), controller_loop).result(20)
        secret_log = io.StringIO()
        m.console.log = secret_log
        try:
            response = m.console.command('desktop portal-pair', 10)
            code = re.search(r'PORTAL_PAIR=(\d{6})', response)[1]
            m.token = json.loads(original_http('POST', '/api/pair', {'code': code}))['token']
            del response, code
        finally:
            m.console.log = m.wire
            secret_log.close()
        m.state['portal_session_refreshed_after_pressure'] = True
        m.save()
    return original_http(method, path, body, auth)


m.http = controlled_http
m.state['controller_finish_fix'] = {
    'installed_during_pressure': True,
    'phase_elapsed_at_install': round(time.monotonic()-m.phase_start,3),
    'method': 'Python 3.14 sys.remote_exec into the owned test process',
    'scope': 'post-pressure evidence retrieval only; packet producers, verification, and fault detection unchanged',
}
m.save()
print('POST_PRESSURE_CONTROL_FIX_INSTALLED', flush=True)
