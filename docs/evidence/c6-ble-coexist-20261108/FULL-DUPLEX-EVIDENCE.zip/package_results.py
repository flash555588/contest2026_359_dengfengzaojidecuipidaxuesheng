"""Validate completed live receipts and package this supplemental soak."""
from pathlib import Path
import ast
import hashlib
import json
import re
import struct
import zipfile
import zlib

out = Path(__file__).resolve().parent
previous = out.parent / 'c6-ble-coexist-20261108'
label = 'duplex-sd-receipts'
state = json.loads((out / (label+'.json')).read_text(encoding='utf-8'))
assert state['passed'] and not state['errors']
assert state['disconnects'] == 0 and state['automatic_reconnects'] == 0
assert state['board_resets_requested'] == 0 and state['c6_uart']['resets'] == 0
assert not state['c6_uart']['faults']
assert not state['wifi']['failures']
assert state['pc_written'] == state['board_verified']
assert state['pc_notified_verified'] == state['board_submitted']
assert state['owned_fixture_removed']
assert all(item['restored'] for item in state['pc_radios_restored'])
assert len(state['phases']) == 2
main = state['phases'][1]
assert main['seconds'] >= 900 and main['down_packets'] == 65536
assert state['board_to_pc_bytes_verified'] >= 1048576
assert state['pc_to_board_bytes_verified'] >= 1048576
assert len(state['health_samples']) >= 256
for sample in state['health_samples']:
    assert all(sample.get(key) == 0 for key in ('counter_exhausted','hci_tx_errors','link_error'))
assert 'link_error=0' in state['transport_after']
assert 'unexpected=0' in state['hid_diagnostics_after']

# Independently re-parse the full board receipts, rather than trust only the
# live controller's counters. This does not open any device or radio.
scope = {'nonce':bytes.fromhex(state['nonce']),'struct':struct,'zlib':zlib}
tree = ast.parse((out/'stress-at-launch.py').read_text())
for node in tree.body:
    if isinstance(node,ast.FunctionDef) and node.name in ('frame','fnv'):
        exec(compile(ast.Module(body=[node],type_ignores=[]),'<offline verification>','exec'),scope)
up = hashlib.sha256()
down = hashlib.sha256()
rx_index = send_count = 0
for name in (label+'-result-0.log',label+'-result-200.log',label+'-drain.log'):
    for line in (out/name).read_text().splitlines():
        matched = re.search(r'BLE_CHANNEL_DATA bytes=(\d+) fnv32=([0-9a-f]{8})',line)
        if matched:
            expected_frame = scope['frame'](rx_index,244,0xa0)
            assert int(matched[1])==244 and matched[2]==scope['fnv'](expected_frame), (name,rx_index)
            up.update(expected_frame)
            rx_index += 1
        matched = re.search(r'c6ble channel (send|receive) result=(-?\d+)',line)
        if matched:
            op,value = matched[1],int(matched[2])
            assert value==0 if op=='send' else value in (0,-11)
            if op=='send':send_count += 1
assert rx_index==state['pc_written']==29849
assert send_count==state['pc_notified_verified']==65736
for index in range(send_count):down.update(scope['frame'](index,20,0xd0))
assert up.hexdigest()==state['upstream_verified_stream_sha256']
assert down.hexdigest()==state['downstream_verified_stream_sha256']
independent = {'passed':True,'ordered_board_rx_frames':rx_index,'board_send_successes':send_count,
               'upstream_expected_stream_sha256':up.hexdigest(),'downstream_expected_stream_sha256':down.hexdigest(),
               'matches_live_controller_digests':True}
(out/'INDEPENDENT-RECEIPT-AUDIT.json').write_text(json.dumps(independent,indent=2))

report = {
    'date': '2026-11-08', 'passed': True,
    'scope': 'PC BLE central <-> already-installed C6/P4 peripheral; independent sustained senders plus Wi-Fi HTTP',
    'candidate_image_sha256': json.loads((previous/'DEPLOYMENT2.json').read_text())['candidate_sha256'],
    'firmware_rebuilt_or_flashed_this_run': False,
    'main_phase_seconds': main['seconds'],
    'main_board_to_pc_packets': main['down_packets'],
    'total_pc_to_board_packets': state['pc_written'],
    'total_pc_to_board_bytes_verified': state['pc_to_board_bytes_verified'],
    'total_board_to_pc_packets': state['pc_notified_verified'],
    'total_board_to_pc_bytes_verified': state['board_to_pc_bytes_verified'],
    'payload_bytes': state['sizes'],
    'verification': {'pc_to_board': 'ordered per-frame FNV32 from complete board SD log; synthetic frame contains sequence and CRC32',
                     'board_to_pc': 'every notification checked byte-for-byte including sequence and CRC32',
                     'accepted_writes_all_drained_and_verified': True,
                     'independent_receipt_and_stream_digest_audit':True},
    'flow_control': {'queue_slots': 4, 'explicit_att_insufficient_resource_retries': state['pc_queue_full_retries'],
                     'ambiguous_write_timeouts_retried': False,
                     'explanation': 'Only explicit ATT 0x11 rejection is retried; queue backpressure is separate from link failure.'},
    'wifi': state['wifi'],
    'bluetooth_unexpected_disconnects': 0,
    'c6_unexpected_reset_markers': 0,
    'c6_uart_fault_markers': [],
    'shared_link_health_samples': len(state['health_samples']),
    'counter_retry_exhaustion': 0, 'hci_send_errors': 0, 'shared_link_error': 0,
    'automatic_reconnects': 0, 'resets_requested': 0,
    'final_transport': state['transport_after'],
    'test_files_removed': True, 'pc_radio_restored': True,
    'observed_c6_loss': False,
    'limits': ['This bounded run did not reproduce C6 loss; it does not prove the intermittent defect impossible.',
               'Downstream frames are 20 bytes due to the existing 80-character console command limit; this is a sustained packet/concurrency test, not a maximum-throughput benchmark.',
               'Reverse-role board-central to a real phone/peripheral is not covered.',
               'No cold power cycle or physical screen acceptance was performed.'],
    'harness_notes': ['Earlier pilots are retained separately and not counted as passed.',
                      'The HTTP file API rejects replacing an existing file; final phase scripts use unique names.',
                      'An earlier serial receipt missed sequence 104 although all logged checksums matched sent frames; complete SD receipts replace UART-only integrity evidence.',
                      'During this run the owned Python controller received a finish-only correction using Python 3.14 remote_exec. It pauses probes after pressure ends and refreshes the expired portal session; BLE traffic, integrity checking and failure detection during pressure were unchanged. The launch source and finish correction are included.'],
    'git': {'new_production_code_changes': False, 'committed': False, 'pushed': False},
}
(out / 'TEST-REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
text = f'''C6 双向持续并发实板压力测试（2026-11-08）

本轮未重新编译或烧录，测试当前板上已有补丁固件。电脑与开发板各自独立发包，不以请求/应答逐轮串行运行；同时连续请求板上 Wi-Fi HTTP 服务。

主压力阶段 {main['seconds']:.1f} 秒（{main['seconds']/60:.1f} 分钟）。
电脑→板子：{state['pc_written']:,} 包，{state['pc_to_board_bytes_verified']:,} 字节，逐包按序校验 FNV32。
板子→电脑：{state['pc_notified_verified']:,} 包，{state['board_to_pc_bytes_verified']:,} 字节，通知逐字节校验。
Wi-Fi：{state['wifi']['success']:,} 次请求成功，0 次失败。
蓝牙意外断连 0、C6 异常重启标记 0、串口故障标记 0。
{len(state['health_samples'])} 个 SDIO/HCI 健康样本中，计数重读耗尽、HCI 发送错误与共享链路错误均为 0。
测试中没有自动重连或重启。

接收队列容量 4，出现 {state['pc_queue_full_retries']:,} 次明确 ATT 0x11 资源不足拒绝；仅在明确未接纳时重试同一个序号，所有最终接纳的包均排空验证。这是应用背压，不计作 C6 失联。

电脑→板子包长 244 字节，板子→电脑包长 20 字节。后者受现有串口命令长度限制，因此本轮验证持续发包、数据完整性与并发稳定性，不能视为最大吞吐率验收。电脑模拟手机，开发板作为 BLE 外围设备；反向角色连接真实外设未覆盖。

结果：本轮没有复现 C6 失联。有限时长测试不能保证原偶发问题永不发生。
测试临时 SD 目录已清理，测试 HID 已关闭，电脑蓝牙恢复测试前状态。未修改生产代码，未 commit/push。
原始完整 SD 回执、序列/校验说明和详细限制见 TEST-REPORT.json 及 {label}.json。
'''
(out / '验证报告.txt').write_text(text,encoding='utf-8')
names = ['stress.py','stress-at-launch.py','finish_control_fix.py','package_results.py','analyze_console_receipts.py','TEST-REPORT.json','验证报告.txt',
         'CONSOLE-PILOT-ANALYSIS.json','INDEPENDENT-RECEIPT-AUDIT.json',label+'.json',label+'-board.log',label+'-c6.log',
         label+'-result-0.log',label+'-result-200.log',label+'-drain.log']
entries = {name:out/name for name in names}
entries['original-patch/c6-ble-coexist.patch'] = previous/'c6-ble-coexist.patch'
entries['original-patch/PATCH-MANIFEST.json'] = previous/'PATCH-MANIFEST.json'
inventory = {name:{'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for name,path in entries.items()}
(out/'BUNDLE-MANIFEST.json').write_text(json.dumps(inventory,indent=2))
entries['BUNDLE-MANIFEST.json'] = out/'BUNDLE-MANIFEST.json'
archive = out/'C6-full-duplex-test-20261108.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as bundle:
    for name,path in sorted(entries.items()): bundle.write(path,name)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for name,item in inventory.items():
        assert hashlib.sha256(bundle.read(name)).hexdigest()==item['sha256']
(out/'BUNDLE-SHA256.txt').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(json.dumps({key:report[key] for key in ('passed','main_phase_seconds','total_pc_to_board_bytes_verified','total_board_to_pc_bytes_verified','wifi','observed_c6_loss')},ensure_ascii=False))
