"""Explain the aborted UART-verification pilot without opening hardware."""
from pathlib import Path
import ast
import json
import re
import struct
import zlib

out = Path(__file__).resolve().parent
state = json.loads((out / 'duplex-sustained.json').read_text(encoding='utf-8'))
tree = ast.parse((out / 'stress.py').read_text())
scope = {'nonce': bytes.fromhex(state['nonce']), 'struct': struct, 'zlib': zlib}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in ('frame', 'fnv'):
        exec(compile(ast.Module(body=[node], type_ignores=[]), '<offline helpers>', 'exec'), scope)
mapping = {scope['fnv'](scope['frame'](n,244,0xa0)): n for n in range(state['pc_written'])}
assert len(mapping) == state['pc_written']
text = (out / 'duplex-sustained-board.log').read_text(encoding='utf-8')
hashes = re.findall(r'BLE_CHANNEL_DATA bytes=244 fnv32=([0-9a-f]{8})',text)
sequences = [mapping.get(value) for value in hashes]
received = int(re.search(r'queued=0 received=(\d+)',state['channel_after'])[1])
report = {
    'pilot': 'duplex-sustained',
    'valid_logged_rx_checksums': len(sequences),
    'logged_sequences': sequences,
    'unrecognized_checksums': [value for value in hashes if value not in mapping],
    'missing_from_serial_receipt': sorted(set(range(received))-set(sequences)),
    'board_received': received,
    'board_rx_queue_after': 0,
    'pc_written': state['pc_written'],
    'conclusion': 'Valid checksum sequence skipped a serial receipt; UART evidence is incomplete. This pilot cannot be accepted as data-integrity proof.',
    'c6_link_error': 0,
    'bluetooth_unexpected_disconnects': 0,
    'replacement': 'producer stdout redirected to owned SD log; verify the complete log after transfer',
}
assert not report['unrecognized_checksums']
assert report['missing_from_serial_receipt']
(out / 'CONSOLE-PILOT-ANALYSIS.json').write_text(json.dumps(report,indent=2))
print(json.dumps({key:value for key,value in report.items() if key!='logged_sequences'},indent=2))
