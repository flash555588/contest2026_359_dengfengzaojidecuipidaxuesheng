/****************************************************************************
 * apps/crypto/openssl_mbedtls_wrapper/include/openssl/tls1.h
 *
 * SPDX-License-Identifier: Apache-2.0
 * SPDX-FileCopyrightText: 2015-2016 Espressif Systems (Shanghai) PTE LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ****************************************************************************/

#ifndef OPENSSL_MBEDTLS_WRAPPER_TLS1_H
#define OPENSSL_MBEDTLS_WRAPPER_TLS1_H

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <openssl/ssl.h>

/****************************************************************************
 * Pre-processor Definitions
 ****************************************************************************/

#define TLS1_AD_DECRYPTION_FAILED       21
#define TLS1_AD_RECORD_OVERFLOW         22
#define TLS1_AD_UNKNOWN_CA              48 /* fatal */
#define TLS1_AD_ACCESS_DENIED           49 /* fatal */
#define TLS1_AD_DECODE_ERROR            50 /* fatal */
#define TLS1_AD_DECRYPT_ERROR           51
#define TLS1_AD_EXPORT_RESTRICTION      60 /* fatal */
#define TLS1_AD_PROTOCOL_VERSION        70 /* fatal */
#define TLS1_AD_INSUFFICIENT_SECURITY   71 /* fatal */
#define TLS1_AD_INTERNAL_ERROR          80 /* fatal */
#define TLS1_AD_INAPPROPRIATE_FALLBACK  86 /* fatal */
#define TLS1_AD_USER_CANCELLED          90
#define TLS1_AD_NO_RENEGOTIATION        100

/* codes 110-114 are from RFC3546 */

#define TLS1_AD_UNSUPPORTED_EXTENSION   110
#define TLS1_AD_CERTIFICATE_UNOBTAINABLE 111
#define TLS1_AD_UNRECOGNIZED_NAME       112
#define TLS1_AD_BAD_CERTIFICATE_STATUS_RESPONSE 113
#define TLS1_AD_BAD_CERTIFICATE_HASH_VALUE 114
#define TLS1_AD_UNKNOWN_PSK_IDENTITY    115 /* fatal */
#define TLS1_AD_NO_APPLICATION_PROTOCOL 120 /* fatal */

/* Special value for method supporting multiple versions */

#define TLS_ANY_VERSION                 0x10000

#define TLS1_VERSION                    0x0301
#define TLS1_1_VERSION                  0x0302
#define TLS1_2_VERSION                  0x0303

#define SSL_TLSEXT_ERR_OK               0
#define SSL_TLSEXT_ERR_NOACK            3

#define TLSEXT_MAXLEN_host_name         255

#ifdef __cplusplus
extern "C"
{
#endif

/****************************************************************************
 * Public Function Prototypes
 ****************************************************************************/

long SSL_set_tlsext_host_name(SSL *s, void *parg);

#ifdef __cplusplus
}
#endif

#endif /* OPENSSL_MBEDTLS_WRAPPER_TLS1_H */
