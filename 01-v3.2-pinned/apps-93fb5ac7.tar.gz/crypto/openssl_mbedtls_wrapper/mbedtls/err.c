/****************************************************************************
 * apps/crypto/openssl_mbedtls_wrapper/mbedtls/err.c
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.  The
 * ASF licenses this file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the
 * License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the
 * License for the specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <openssl/err.h>
#include <mbedtls/error.h>
#include <mbedtls/cipher.h>
#include <errno.h>

/****************************************************************************
 * Public Functions
 ****************************************************************************/

unsigned long ERR_peek_last_error(void)
{
  return errno;
}

void ERR_free_strings(void)
{
}

void ERR_error_string_n(unsigned long e, char *buf, size_t len)
{
  mbedtls_strerror(e, buf, len);
}

void ERR_clear_error(void)
{
}

unsigned long ERR_get_error(void)
{
  return errno;
}

void ERR_remove_state(unsigned long pid)
{
}

int ERR_load_crypto_strings(void)
{
  return 1;
}

void ERR_print_errors_cb(int (*cb)(const char *str, size_t len, void *u),
                         void *u)
{
}
