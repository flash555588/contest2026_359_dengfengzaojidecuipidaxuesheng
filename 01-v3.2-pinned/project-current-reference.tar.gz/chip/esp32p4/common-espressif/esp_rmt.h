/****************************************************************************
 * arch/risc-v/src/common/espressif/esp_rmt.h
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.  The
 * ASF licenses this file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the
 * License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the
 * License for the specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/

#ifndef __ARCH_RISC_V_SRC_COMMON_ESPRESSIF_ESP_RMT_H
#define __ARCH_RISC_V_SRC_COMMON_ESPRESSIF_ESP_RMT_H

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <nuttx/config.h>
#include <semaphore.h>
#include <sys/types.h>
#include <stdint.h>
#include <stdbool.h>
#include <nuttx/circbuf.h>
#include <nuttx/spinlock.h>

/****************************************************************************
 * Pre-processor Definitions
 ****************************************************************************/

#define RMT_MEM_ITEM_NUM SOC_RMT_MEM_WORDS_PER_CHANNEL

#define RMT_DEFAULT_CLK_DIV 1

/* Channel can work during APB clock scaling */

#define RMT_CHANNEL_FLAGS_AWARE_DFS (1 << 0)

/* Invert RMT signal */

#define RMT_CHANNEL_FLAGS_INVERT_SIG (1 << 1)

/****************************************************************************
 * Public Types
 ****************************************************************************/

/* The RMT peripheral vtable */

struct rmt_dev_s;

struct rmt_ops_s
{
  CODE int      (*open)(FAR struct rmt_dev_s *dev);
  CODE int      (*close)(FAR struct rmt_dev_s *dev);
  CODE ssize_t  (*write)(FAR struct rmt_dev_s *dev,
                         FAR const char *buffer,
                         size_t buflen);
  CODE ssize_t  (*read)(FAR struct rmt_dev_s *dev,
                        FAR char *buffer,
                        size_t buflen);
};

/* RMT device structure — initial fields visible to upper-half drivers.
 * The ESP lower-half extends this with hardware-specific fields.
 */

struct rmt_dev_s
{
  FAR const struct rmt_ops_s *ops;
  FAR struct circbuf_s       *circbuf;
  sem_t                      *recvsem;
  int                         minor;
};

/****************************************************************************
 * Public Data
 ****************************************************************************/

#ifndef __ASSEMBLY__
#ifdef __cplusplus
extern "C"
{
#endif

/****************************************************************************
 * Public Functions Prototypes
 ****************************************************************************/

#if defined(CONFIG_ESP_RMT)

/****************************************************************************
 * Name: esp_rmt_rx_init
 *
 * Description:
 *   Initialize the selected RMT device in TX mode
 *
 * Input Parameters:
 *   tx_pin  - The pin used for the TX channel
 *
 * Returned Value:
 *   Valid RMT device structure reference on success; NULL, otherwise.
 *
 ****************************************************************************/

struct rmt_dev_s *esp_rmt_rx_init(int tx_pin);

/****************************************************************************
 * Name: esp_rmt_tx_init
 *
 * Description:
 *   Initialize the selected RMT device in RX mode
 *
 * Input Parameters:
 *   rx_pin  - The pin used for the RX channel
 *
 * Returned Value:
 *   Valid RMT device structure reference on success; NULL, otherwise.
 *
 ****************************************************************************/

struct rmt_dev_s *esp_rmt_tx_init(int rx_pin);

#endif

#ifdef __cplusplus
}
#endif
#endif /* __ASSEMBLY__ */

#endif /* __ARCH_RISC_V_SRC_COMMON_ESPRESSIF_ESP_RMT_H */
