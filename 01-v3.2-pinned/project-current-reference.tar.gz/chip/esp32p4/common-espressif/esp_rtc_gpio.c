/****************************************************************************
 * arch/risc-v/src/common/espressif/esp_rtc_gpio.c
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.  The
 * ASF licenses this file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the
 * License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the
 * License for the specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <nuttx/config.h>

#include <assert.h>
#include <debug.h>
#include <stdbool.h>
#include <stdint.h>
#include <sys/types.h>

#include <nuttx/arch.h>
#include <nuttx/irq.h>

#include "irq.h"
#include "riscv_internal.h"
#include "esp_irq.h"
#include "esp_rtc_gpio.h"
#include "hal/rtc_io_periph.h"
#include "hal/rtc_io_hal.h"
#include "soc/rtc_cntl_periph.h"
#include "soc/periph_defs.h"
#if defined(CONFIG_ARCH_CHIP_ESP32C6) || defined(CONFIG_ARCH_CHIP_ESP32P4)
#include "driver/rtc_io.h"
#include "hal/rtc_io_ll.h"
#include "hal/rtc_io_hal.h"
#include "io_mux.h"
#endif

/****************************************************************************
 * Pre-processor Definitions
 ****************************************************************************/

/****************************************************************************
 * Private Types
 ****************************************************************************/

/* Structure to store RTC GPIO interrupt handlers */

struct rtcio_handler_s
{
  xcpt_t        handler;  /* User interrupt handler */
  void          *arg;     /* Argument for handler */
};

/****************************************************************************
 * Private Data
 ****************************************************************************/

#ifdef CONFIG_ARCH_CHIP_ESP32C3
#ifdef CONFIG_ESPRESSIF_RTCIO_IRQ
static int g_rtcio_cpuint;
static uint32_t last_status;
static struct rtcio_handler_s g_rtcio_handlers[ESP_NIRQ_RTCIO];

static const int rtc_irq_reg_shift[ESP_NIRQ_RTCIO] =
{
  RTC_CNTL_SLP_WAKEUP_INT_ENA_S,
  RTC_CNTL_SLP_REJECT_INT_ENA_S,
  RTC_CNTL_WDT_INT_ENA_S,
  RTC_CNTL_BROWN_OUT_INT_ENA_S,
  RTC_CNTL_MAIN_TIMER_INT_ENA_S,
  RTC_CNTL_SWD_INT_ENA_S,
  RTC_CNTL_XTAL32K_DEAD_INT_ENA_S,
  RTC_CNTL_GLITCH_DET_INT_ENA_S,
  RTC_CNTL_BBPLL_CAL_INT_ENA_S
};
#define RTC_IRQ_REG_SHIFT(x)        rtc_irq_reg_shift[x]
#endif /* CONFIG_ESPRESSIF_RTCIO_IRQ */

/****************************************************************************
 * Private Functions
 ****************************************************************************/

/****************************************************************************
 * Name: rtcio_dispatch
 *
 * Description:
 *   Second level dispatch for the RTC interrupt.
 *
 * Input Parameters:
 *   irq        - The IRQ number;
 *   reg_status - Pointer to a copy of the interrupt status register.
 *
 * Returned Value:
 *   None.
 *
 ****************************************************************************/

#ifdef CONFIG_ESPRESSIF_RTCIO_IRQ
static void rtcio_dispatch(int irq, void *context, uint32_t *reg_status)
{
  uint32_t status = *reg_status;
  uint32_t mask;
  int i;

  /* Check each bit in the status register */

  for (i = 0; i < ESP_NIRQ_RTCIO && status != 0; i++)
    {
      /* Check if there is an interrupt pending for this type */

      mask = (UINT32_C(1) << RTC_IRQ_REG_SHIFT(i));
      if ((status & mask) != 0)
        {
          /* Call the registered handler if one exists */

          if (g_rtcio_handlers[i].handler != NULL)
            {
              g_rtcio_handlers[i].handler(irq,
                                          (void *)reg_status,
                                          g_rtcio_handlers[i].arg);
            }

          /* Clear the bit in the status so that we might execute this loop
           * sooner.
           */

          status &= ~mask;
        }
    }
}

/****************************************************************************
 * Name: rtcio_interrupt
 *
 * Description:
 *   RTC interrupt handler.
 *
 * Input Parameters:
 *   irq     - The IRQ number;
 *   context - The interrupt context;
 *   args    - The arguments passed to the handler.
 *
 * Returned Value:
 *   Zero (OK).
 *
 ****************************************************************************/

static int rtcio_interrupt(int irq, void *context, void *arg)
{
  /* Read and clear the lower RTC interrupt status */

  last_status = getreg32(RTC_CNTL_INT_ST_REG);
  putreg32(last_status, RTC_CNTL_INT_CLR_REG);

  /* Dispatch pending interrupts in the RTC status register */

  rtcio_dispatch(ESP_FIRST_RTCIOIRQ, context, &last_status);

  return OK;
}
#endif /* CONFIG_ESPRESSIF_RTCIO_IRQ */

/****************************************************************************
 * Public Functions
 ****************************************************************************/

/****************************************************************************
 * Name: esp_rtcioirqinitialize
 *
 * Description:
 *   Initialize logic to support a second level of interrupt decoding for
 *   RTC IRQs.
 *
 * Input Parameters:
 *   None.
 *
 * Returned Value:
 *   None.
 *
 ****************************************************************************/

#ifdef CONFIG_ESPRESSIF_RTCIO_IRQ
void esp_rtcioirqinitialize(void)
{
  int i;

  /* Initialize handler array */

  for (i = 0; i < ESP_NIRQ_RTCIO; i++)
    {
      g_rtcio_handlers[i].handler = NULL;
      g_rtcio_handlers[i].arg = NULL;
    }

  /* Setup the RTCIO interrupt. */

  g_rtcio_cpuint = esp_setup_irq(ETS_RTC_CORE_INTR_SOURCE,
                                 1, ESP_IRQ_TRIGGER_LEVEL,
                                 rtcio_interrupt, NULL);
  DEBUGASSERT(g_rtcio_cpuint >= 0);

  /* Enable the interrupt handler */

  up_enable_irq(ESP_IRQ_RTC_CORE);
}

/****************************************************************************
 * Name: esp_rtcioirqattach
 *
 * Description:
 *   Attach an interrupt handler to a specified RTC IRQ
 *
 * Input Parameters:
 *   irq     - RTC IRQ number to attach the handler to
 *   handler - Interrupt handler function
 *   arg     - Argument to pass to the handler
 *
 * Returned Value:
 *   Zero (OK) is returned on success; A negated errno value is returned
 *   to indicate the nature of any failure.
 *
 ****************************************************************************/

int esp_rtcioirqattach(int irq, xcpt_t handler, void *arg)
{
  int bit;

  DEBUGASSERT(irq >= ESP_FIRST_RTCIOIRQ &&
              irq <= ESP_LAST_RTCIOIRQ);

  /* Convert the IRQ number to the corresponding bit */

  bit = irq - ESP_FIRST_RTCIOIRQ;

  DEBUGASSERT(bit >= 0 && bit < ESP_NIRQ_RTCIO);

  /* Store the handler and argument */

  g_rtcio_handlers[bit].handler = handler;
  g_rtcio_handlers[bit].arg = arg;

  return OK;
}

/****************************************************************************
 * Name: esp_rtcioirqdetach
 *
 * Description:
 *   Detach an interrupt handler from a specified RTC IRQ
 *
 * Input Parameters:
 *   irq - RTC IRQ number to detach the handler from
 *
 * Returned Value:
 *   Zero (OK) is returned on success; A negated errno value is returned
 *   to indicate the nature of any failure.
 *
 ****************************************************************************/

int esp_rtcioirqdetach(int irq)
{
  int bit;

  DEBUGASSERT(irq >= ESP_FIRST_RTCIOIRQ &&
              irq <= ESP_LAST_RTCIOIRQ);

  /* Convert the IRQ number to the corresponding bit */

  bit = irq - ESP_FIRST_RTCIOIRQ;

  DEBUGASSERT(bit >= 0 && bit < ESP_NIRQ_RTCIO);

  /* Clear the handler and argument */

  g_rtcio_handlers[bit].handler = NULL;
  g_rtcio_handlers[bit].arg = NULL;

  return OK;
}

/****************************************************************************
 * Name: esp_rtcioirqenable
 *
 * Description:
 *   Enable the interrupt for the specified RTC peripheral IRQ.
 *
 * Input Parameters:
 *   irq - The IRQ number.
 *
 * Returned Value:
 *   None.
 *
 ****************************************************************************/

void esp_rtcioirqenable(int irq)
{
  uintptr_t regaddr = RTC_CNTL_INT_ENA_REG;
  uint32_t regval;
  int bit;

  DEBUGASSERT(irq >= ESP_FIRST_RTCIOIRQ &&
              irq <= ESP_LAST_RTCIOIRQ);

  /* Convert the IRQ number to the corresponding bit */

  bit = RTC_IRQ_REG_SHIFT(irq - ESP_FIRST_RTCIOIRQ);

  /* Get the address of the GPIO PIN register for this pin */

  up_disable_irq(ESP_IRQ_RTC_CORE);

  regval = getreg32(regaddr) | (UINT32_C(1) << bit);
  putreg32(regval, regaddr);

  up_enable_irq(ESP_IRQ_RTC_CORE);
}

/****************************************************************************
 * Name: esp_rtcioirqdisable
 *
 * Description:
 *   Disable the interrupt for the specified RTC peripheral IRQ.
 *
 * Input Parameters:
 *   irq - The IRQ number.
 *
 * Returned Value:
 *   None.
 *
 ****************************************************************************/

void esp_rtcioirqdisable(int irq)
{
  uintptr_t regaddr = RTC_CNTL_INT_ENA_REG;
  uint32_t regval;
  int bit;

  DEBUGASSERT(irq >= ESP_FIRST_RTCIOIRQ &&
              irq <= ESP_LAST_RTCIOIRQ);

  /* Convert the IRQ number to the corresponding bit */

  bit = RTC_IRQ_REG_SHIFT(irq - ESP_FIRST_RTCIOIRQ);

  /* Disable IRQ */

  up_disable_irq(ESP_IRQ_RTC_CORE);

  regval = getreg32(regaddr) & (~(UINT32_C(1) << bit));
  putreg32(regval, regaddr);

  up_enable_irq(ESP_IRQ_RTC_CORE);
}
#endif /* CONFIG_ESPRESSIF_RTCIO_IRQ */
#endif /* CONFIG_ARCH_CHIP_ESP32C3 */

/****************************************************************************
 * Name: esp_rtcio_config_gpio
 *
 * Description:
 *   Configure a RTC GPIO pin based on encoded pin attributes
 *
 * Input Parameters:
 *   pin  - RTC GPIO pin to be configured.
 *   mode - Attributes to be configured for the selected RTC GPIO pin.
 *
 * Returned Value:
 *   Zero (OK) on success, or -1 (ERROR) in case of failure.
 *
 ****************************************************************************/

#if defined(CONFIG_ARCH_CHIP_ESP32C6) || defined(CONFIG_ARCH_CHIP_ESP32P4)
int esp_rtcio_config_gpio(int pin, enum esp_rtc_gpio_mode_e mode)
{
  int ret = rtc_gpio_init(pin);
  if (ret != OK)
    {
      return ret;
    }

  ret = rtc_gpio_set_direction(pin, mode);

  return ret;
}

/****************************************************************************
 * Name: esp_rtcio_read
 *
 * Description:
 *   Read one or zero from the selected RTC GPIO pin
 *
 * Input Parameters:
 *   pin - RTC GPIO pin to be read.
 *
 * Returned Value:
 *   The boolean representation of the input value (true/false).
 *
 ****************************************************************************/

int esp_rtcio_read(int pin)
{
  return rtc_gpio_get_level(pin);
}

/****************************************************************************
 * Name: esp_rtcio_write
 *
 * Description:
 *   Write one or zero to the selected RTC GPIO pin
 *
 * Input Parameters:
 *   pin   - GPIO pin to be modified.
 *   value - The value to be written (0 or 1).
 *
 * Returned Value:
 *   None
 *
 ****************************************************************************/

void esp_rtcio_write(int pin, bool value)
{
  rtc_gpio_set_level(pin, value);
}
#endif /* CONFIG_ARCH_CHIP_ESP32C6 || CONFIG_ARCH_CHIP_ESP32P4 */
