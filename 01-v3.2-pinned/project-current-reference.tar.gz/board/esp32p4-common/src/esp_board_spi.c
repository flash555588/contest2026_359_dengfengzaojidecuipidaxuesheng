/****************************************************************************
 * boards/risc-v/esp32p4/common/src/esp_board_spi.c
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.  The
 * ASF licenses this file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the
 * License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the
 * License for the specific language governing permissions and limitations
 * under the License.
 *
 ****************************************************************************/

/****************************************************************************
 * Included Files
 ****************************************************************************/

#include <nuttx/config.h>

#include <stdint.h>
#include <stdbool.h>
#include <debug.h>

#include <nuttx/spi/spi.h>

#include "espressif/esp_gpio.h"

/****************************************************************************
 * Private Functions
 ****************************************************************************/

/****************************************************************************
 * Public Functions
 ****************************************************************************/

/****************************************************************************
 * Name: esp_spi2_status
 ****************************************************************************/

#ifdef CONFIG_ESPRESSIF_SPI2

uint8_t esp_spi2_status(struct spi_dev_s *dev, uint32_t devid)
{
  uint8_t status = 0;

  return status;
}

#endif

/****************************************************************************
 * Name: esp_spi2_select
 ****************************************************************************/

#if defined(CONFIG_ESPRESSIF_SPI2) && defined(CONFIG_ESPRESSIF_SPI_UDCS)
void esp_spi2_select(struct spi_dev_s *dev, uint32_t devid, bool select)
{
  esp_gpiowrite(CONFIG_ESPRESSIF_SPI2_CSPIN, !select);
}
#endif

/****************************************************************************
 * Name: esp_spi2_cmddata
 ****************************************************************************/

#if defined(CONFIG_ESPRESSIF_SPI2) && defined(CONFIG_SPI_CMDDATA)

int esp_spi2_cmddata(struct spi_dev_s *dev, uint32_t devid, bool cmd)
{
  if (devid == SPIDEV_DISPLAY(0))
    {
      /*  This is the Data/Command control pad which determines whether the
       *  data bits are data or a command.
       */

      esp_gpiowrite(CONFIG_ESPRESSIF_SPI2_MISOPIN, !cmd);

      return OK;
    }

  spiinfo("devid: %" PRIu32 " CMD: %s\n", devid, cmd ? "command" :
          "data");

  return -ENODEV;
}

#endif

#ifdef CONFIG_ESPRESSIF_SPI3

/****************************************************************************
 * Name: esp_spi3_status
 ****************************************************************************/

uint8_t esp_spi3_status(struct spi_dev_s *dev, uint32_t devid)
{
  uint8_t status = 0;

  return status;
}

#endif

/****************************************************************************
 * Name: esp_spi2_select
 ****************************************************************************/

#if defined(CONFIG_ESPRESSIF_SPI3) && defined(CONFIG_ESPRESSIF_SPI_UDCS)
void esp_spi3_select(struct spi_dev_s *dev, uint32_t devid, bool select)
{
  esp_gpiowrite(CONFIG_ESPRESSIF_SPI3_CSPIN, !select);
}
#endif

/****************************************************************************
 * Name: esp_spi3_cmddata
 ****************************************************************************/

#if defined(CONFIG_ESPRESSIF_SPI3) && defined(CONFIG_SPI_CMDDATA)

int esp_spi3_cmddata(struct spi_dev_s *dev, uint32_t devid, bool cmd)
{
  if (devid == SPIDEV_DISPLAY(0))
    {
      /*  This is the Data/Command control pad which determines whether the
       *  data bits are data or a command.
       */

      esp_gpiowrite(CONFIG_ESPRESSIF_SPI3_MISOPIN, !cmd);

      return OK;
    }

  spiinfo("devid: %" PRIu32 " CMD: %s\n", devid, cmd ? "command" :
          "data");

  return -ENODEV;
}

#endif
