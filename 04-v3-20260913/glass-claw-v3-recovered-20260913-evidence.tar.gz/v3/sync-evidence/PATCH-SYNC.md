# v3 补丁与特性同步证据

本候选的隔离 OpenVela v3 树包含以下已解析语义：RPC 序列化前尺寸检查、完整 RPC
事务互斥、唯一 UID 与互斥响应邮箱、RPC 等待期间 c6net 停止争抢 Hosted 响应窗口、
RX 分发所有权、Wi-Fi 事件同步、扫描结果边界、daemon 创建失败重试、链路代际快照、
C6 radio prepare、SDIO R4/R5 响应处理、CMD53 读错误传播，以及 OpenVela 当前头文件
与锁接口兼容修复。

桌面侧同步了 `glass_ui.inc`、`glass_files.inc`、`glass_wifi.inc`，并把
`desktop_worker.c`、`desktop_backend.c` 编入 `CONFIG_SYSTEM_C6_DESKTOP`。最终 ELF
已核验 `c6_desktop_worker_start`、`g_c6_desktop_backend`、`c6net_prepare`、
`c6net_get_link_snapshot`、`esp_hosted_rpc_is_waiting` 和
`esp_hosted_rpc_wifi_scan_results`。

`patches/` 保存各独立补丁的原始交付件；部分补丁随后由邮箱、轮询所有权和桌面组合器
继续修改同一区域，因此不应以“整块反向 git apply 能否成功”判断是否存在。应检查上述
语义标记、最终编译和测试结果。`tools/` 保存本次使用的组合、配置与联合构建脚本。

明确排除项：Hosted BLE 传输只允许 pre-v3，未同步进 v3；没有刷机、C6 射频、DHCP、
真实 Wi-Fi、相机、屏幕或触摸硬件验收。
