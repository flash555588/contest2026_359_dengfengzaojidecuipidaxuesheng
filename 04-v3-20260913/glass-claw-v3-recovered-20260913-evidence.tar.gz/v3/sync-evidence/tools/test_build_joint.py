"""Check that copying a configured tree cannot retain writable baseline links."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location(
    "build_joint", Path(__file__).resolve().parents[1] / "tools/build_joint.py")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class RelocateTest(unittest.TestCase):
    def test_baseline_links_and_config_are_retargeted(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory) / "baseline"
            copy = Path(directory) / "copy"
            base.mkdir()
            copy.mkdir()
            (base / "real").write_text("baseline")
            (copy / "real").write_text("copy")
            (copy / "absolute").symlink_to(base / "real")
            (copy / "relative").symlink_to("real")
            (copy / "Kconfig").write_text(f'source "{base}/real"\n')
            MODULE.relocate(base, copy)
            (copy / "absolute").write_text("changed")
            self.assertEqual((base / "real").read_text(), "baseline")
            self.assertEqual((copy / "relative").read_text(), "changed")
            self.assertEqual((copy / "Kconfig").read_text(), f'source "{copy}/real"\n')

    def test_unreviewed_external_link_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            copy = Path(directory) / "copy"
            copy.mkdir()
            (copy / "external").symlink_to("/outside-the-baseline")
            with self.assertRaisesRegex(RuntimeError, "external symlink"):
                MODULE.relocate(Path(directory) / "baseline", copy)


class BuildLogTest(unittest.TestCase):
    def check(self, contents):
        with tempfile.TemporaryDirectory() as directory:
            log = Path(directory) / "build.log"
            log.write_text(contents)
            MODULE.check_build_log(log)

    def test_normal_warnings_are_accepted(self):
        self.check("warning: unused variable 'preferences'\nLD: nuttx\n")

    def test_compiler_fatal_error_is_rejected(self):
        with self.assertRaisesRegex(RuntimeError, "fatal error"):
            self.check("source.c:15:10: fatal error: mbedtls/base64.h: No such file\n")

    def test_recursive_wrapper_failure_is_rejected(self):
        with self.assertRaisesRegex(RuntimeError, "ERROR"):
            self.check("ERROR: riscv32-esp-elf-gcc failed: 1\nLD: nuttx\n")

    def test_make_error_is_rejected(self):
        with self.assertRaisesRegex(RuntimeError, "make"):
            self.check("make[2]: *** [Makefile:42: object.o] Error 2\n")


class ConfigNamesTest(unittest.TestCase):
    def test_default_build_does_not_force_c6_desktop(self):
        requested, required = MODULE.config_names()
        self.assertNotIn("SYSTEM_C6_DESKTOP", requested)
        self.assertNotIn("SYSTEM_C6_DESKTOP", required)

    def test_c6_desktop_is_requested_and_verified(self):
        requested, required = MODULE.config_names(c6_desktop=True)
        self.assertIn("SYSTEM_C6_DESKTOP", requested)
        self.assertIn("SYSTEM_C6_DESKTOP", required)


class RequiredSymbolNamesTest(unittest.TestCase):
    def test_v3_requires_modular_camera_chain(self):
        symbols = MODULE.required_symbol_names("v3")
        self.assertIn("board_camera_initialize", symbols)
        self.assertIn("sc2336_initialize", symbols)
        self.assertIn("esp_mipi_csi_initialize", symbols)

    def test_c6_desktop_requires_worker_network_and_rpc(self):
        symbols = MODULE.required_symbol_names("v3", c6_desktop=True)
        for name in ("c6_desktop_worker_start", "g_c6_desktop_backend",
                     "c6net_prepare", "c6net_get_link_snapshot",
                     "esp_hosted_rpc_is_waiting", "esp_hosted_rpc_wifi_scan_results"):
            self.assertIn(name, symbols)


class IsolatedTreeTest(unittest.TestCase):
    def test_only_isolated_copy_is_removed(self):
        with tempfile.TemporaryDirectory() as directory:
            baseline = Path(directory) / "baseline/espclaw"
            copied = Path(directory) / "copy/espclaw"
            baseline.mkdir(parents=True)
            copied.mkdir(parents=True)
            (baseline / "marker").write_text("baseline")
            (copied / "marker").write_text("copy")
            MODULE.remove_isolated_tree(copied)
            self.assertEqual((baseline / "marker").read_text(), "baseline")
            self.assertFalse(copied.exists())

    def test_symlink_is_unlinked_without_removing_target(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "target"
            link = Path(directory) / "espclaw"
            target.mkdir()
            (target / "marker").write_text("target")
            link.symlink_to(target, target_is_directory=True)
            MODULE.remove_isolated_tree(link)
            self.assertFalse(link.exists())
            self.assertEqual((target / "marker").read_text(), "target")


if __name__ == "__main__":
    unittest.main()
