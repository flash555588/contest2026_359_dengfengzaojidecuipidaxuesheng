#!/usr/bin/env python3
"""Build an isolated glass desktop / ESP-Claw integration candidate in WSL."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

DESKTOP_SOURCES = (
    "desktop_main.c", "glass_ui.inc", "glass_dashboard.h",
    "qpk_runtime.c", "qpk_runtime.h", "homeassistant_resource.c",
    "glass_wallpaper.h", "glass_music_assets.inc", "glass_settings_store.h",
    "glass_files.inc",
    "glass_wifi.inc",
)

BUILD_FAILURE_PATTERNS = (
    re.compile(r"fatal error:", re.IGNORECASE),
    re.compile(r"^ERROR:\s+.*\sfailed:\s*[1-9]\d*\s*$", re.IGNORECASE | re.MULTILINE),
    re.compile(r"^make(?:\[\d+\])?: \*\*\* .*Error [1-9]\d*\s*$", re.MULTILINE),
)


def run(args, *, cwd=None, env=None):
    print("+", " ".join(map(str, args)), flush=True)
    subprocess.run(list(map(str, args)), cwd=cwd, env=env, check=True)


def check_build_log(path):
    """Reject recursive build failures even if the top-level make exits zero."""
    contents = path.read_text(encoding="utf-8", errors="replace")
    for pattern in BUILD_FAILURE_PATTERNS:
        match = pattern.search(contents)
        if match:
            line = contents[match.start():].splitlines()[0]
            raise RuntimeError(f"Build log contains a failure marker: {line}")


def config_names(c6_desktop=False):
    """Return requested and required Kconfig symbols for this build."""
    requested = ["NETUTILS_WEBCLIENT", "NETUTILS_CJSON", "SYSTEM_ESPCLAW",
                 "LV_USE_CHART", "LV_USE_TINY_TTF"]
    required = ["SYSTEM_ESPCLAW", "NETUTILS_WEBCLIENT",
                "NETUTILS_NETLIB_GENERICURLPARSER", "PTHREAD_MUTEX_TYPES"]
    if c6_desktop:
        requested.append("SYSTEM_C6_DESKTOP")
        required.append("SYSTEM_C6_DESKTOP")
    return requested, required


def required_symbol_names(variant, c6_desktop=False):
    """Return runtime entry points that must survive the final firmware link."""
    names = ["espclaw_main", "claw_command_main", "claw_core_start", "desktop_main"]
    if variant == "v3":
        names.extend(("board_camera_initialize", "sc2336_initialize",
                      "esp_mipi_csi_initialize"))
    if c6_desktop:
        names.extend(("c6_desktop_worker_start", "g_c6_desktop_backend",
                      "c6net_prepare", "c6net_get_link_snapshot",
                      "esp_hosted_rpc_is_waiting", "esp_hosted_rpc_wifi_scan_results"))
    return names


def run_logged(args, log_path, *, cwd=None, env=None):
    """Run a command while streaming and retaining its combined output."""
    command = list(map(str, args))
    print("+", " ".join(command), flush=True)
    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True, errors="replace",
                                   bufsize=1)
        for line in process.stdout:
            sys.stdout.write(line)
            sys.stdout.flush()
            log.write(line)
        returncode = process.wait()
    if returncode:
        raise subprocess.CalledProcessError(returncode, command)
    check_build_log(log_path)


def remove_isolated_tree(path):
    """Remove an inherited directory only from the isolated copy."""
    if path.is_symlink():
        path.unlink()
    elif path.exists():
        shutil.rmtree(path)


def relocate(source, target):
    """Retarget copied absolute links and generated Kconfig source paths."""
    for directory, dirs, files in os.walk(target, followlinks=False):
        dirs[:] = [name for name in dirs if name != ".git"]
        for name in dirs + files:
            path = Path(directory) / name
            if path.is_symlink():
                link = os.readlink(path)
                if link.startswith(str(source) + "/"):
                    path.unlink()
                    path.symlink_to(str(target) + link[len(str(source)):])
                elif os.path.isabs(link):
                    raise RuntimeError(f"Unreviewed external symlink: {path} -> {link}")
            elif name in ("Kconfig", ".config", ".config.old"):
                original = path.read_text()
                changed = original.replace(str(source) + "/", str(target) + "/")
                if changed != original:
                    path.write_text(changed)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("variant", choices=("v1", "v3"))
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--toolchain", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--refresh-desktop", action="store_true",
                        help="Explicitly refresh desktop sources in an existing isolated workspace")
    parser.add_argument("--c6-desktop", action="store_true",
                        help="Enable and verify the composed ESP32-C6 desktop networking backend")
    parser.add_argument("--jobs", type=int, default=8)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    source = args.baseline.resolve()
    tree = args.workspace.resolve()
    output = args.output.resolve()
    if tree == source or source in tree.parents or tree in source.parents:
        parser.error("Workspace must be separate from baseline")
    if any(char.isspace() or char in "()" for char in str(tree)):
        parser.error("NuttX workspace path must not contain spaces or parentheses")
    env = os.environ.copy()
    env["PATH"] = f"{args.toolchain}:{Path.home() / '.local/bin'}:" + env["PATH"]
    env["CROSSDEV"] = "riscv32-esp-elf-"
    tls = tree / "claw-tls-source"
    env["ESPCLAW_TLS_CFLAGS"] = " ".join(f"-I{tls / path}" for path in (
        "include", "tf-psa-crypto/include", "tf-psa-crypto/drivers/builtin/include"))
    marker = tree / "joint-inputs.json"
    if not args.resume:
        if tree.exists() or output.exists():
            parser.error("Fresh workspace and output required")
        tree.mkdir(parents=True)
        output.mkdir(parents=True)
        for name in ("nuttx", "apps"):
            run(["cp", "-a", "--reflink=auto", source / name, tree / name])
        relocate(source, tree)
        tls.symlink_to(root.parent / "upstream/mbedtls-4.0.0")
        staged_app = tree / "apps/system/espclaw"
        remove_isolated_tree(staged_app)
        run([sys.executable, root / "tools/stage_app.py", staged_app])
        desktop = tree / "apps/system/desktop"
        glass = root.parent / "camera-app/glass-desktop"
        inputs = {}
        for name in DESKTOP_SOURCES:
            shutil.copy2(glass / name, desktop / name)
            inputs[name] = hashlib.sha256((glass / name).read_bytes()).hexdigest()
        music_vendor = desktop / "vendor/lvgl-music"
        remove_isolated_tree(music_vendor)
        shutil.copytree(glass / "vendor/lvgl-music", music_vendor)
        marker.write_text(json.dumps({"variant": args.variant, "baseline": str(source),
                                      "desktop_sha256": inputs}, indent=2) + "\n")
        # Remove baseline objects/dependencies before resolving the new configuration.
        run(["make", "clean"], cwd=tree / "nuttx", env=env)
    elif not marker.is_file() or json.loads(marker.read_text())["variant"] != args.variant:
        parser.error("Resume requires a matching prepared workspace")
    if args.refresh_desktop:
        if not args.resume:
            parser.error("--refresh-desktop requires --resume")
        metadata = json.loads(marker.read_text())
        glass = root.parent / "camera-app/glass-desktop"
        desktop = tree / "apps/system/desktop"
        for name in DESKTOP_SOURCES:
            shutil.copy2(glass / name, desktop / name)
            metadata["desktop_sha256"][name] = hashlib.sha256((glass / name).read_bytes()).hexdigest()
        marker.write_text(json.dumps(metadata, indent=2) + "\n")
    # These generated targets have no dependency on newly added applications.
    app = tree / "apps/system/espclaw"
    error_source = tree / "nuttx/arch/risc-v/src/esp32p4/esp-hal-3rdparty/components/esp_common/src/esp_err_to_name.c"
    shutil.copy2(error_source, app / "port/esp_err_to_name.c")
    sources = app / "sources.mk"
    if "port/esp_err_to_name.c" not in sources.read_text():
        sources.write_text(sources.read_text() + "\nCSRCS += port/esp_err_to_name.c\n")
    manifest_path = app / "SOURCE-MANIFEST.json"
    manifest = json.loads(manifest_path.read_text())
    for name in ("port/esp_err_to_name.c", "sources.mk"):
        manifest[name] = hashlib.sha256((app / name).read_bytes()).hexdigest()
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    # Invalidate only the two generated menus, inside the isolated tree.
    for relative in ("apps/Kconfig", "apps/system/Kconfig"):
        (tree / relative).unlink(missing_ok=True)
    run(["make", "-C", tree / "apps", "preconfig", f"TOPDIR={tree / 'nuttx'}"], env=env)
    config = tree / "nuttx/.config"
    requested_configs, required_configs = config_names(args.c6_desktop)
    for name in requested_configs:
        run(["kconfig-tweak", "--file", config, "--enable", name], env=env)
    if args.variant == "v1":
        run(["kconfig-tweak", "--file", config, "--disable", "ESPRESSIF_CPU_FREQ_360",
             "--disable", "ESPRESSIF_CPU_FREQ_90", "--enable", "ESPRESSIF_CPU_FREQ_180"], env=env)
    run(["kconfig-tweak", "--file", config, "--disable", "ESP32P4_SKIP_EARLY_DISPLAY"], env=env)
    run(["make", "olddefconfig"], cwd=tree / "nuttx", env=env)
    resolved = config.read_text()
    if "CONFIG_ESP32P4_SKIP_EARLY_DISPLAY=y" in resolved.splitlines():
        raise RuntimeError("Display registration must not be skipped")
    for name in required_configs:
        if f"CONFIG_{name}=y\n" not in resolved:
            raise RuntimeError(f"Kconfig did not enable {name}")
    if args.prepare_only:
        return
    run(["make", "context", f"-j{args.jobs}"], cwd=tree / "nuttx", env=env)
    # Rebuild with resolved configuration, including the pthread mutex ABI.
    tls_output = tree / ("joint-tls-" + hashlib.sha256(config.read_bytes()).hexdigest()[:16])
    if not tls_output.exists():
        run(["bash", root / "tools/build_tls_target.sh", tree, args.toolchain, tls_output], env=env)
    if (tls_output / "resolved.config").read_bytes() != (tree / "nuttx/.config").read_bytes():
        raise RuntimeError("TLS libraries were built with a different configuration")
    staging = tree / "apps/staging"
    staging.mkdir(exist_ok=True)
    for name in ("libmbedtls.a", "libmbedx509.a", "libtfpsacrypto.a"):
        shutil.copy2(tls_output / name, staging / name)
    build_log = output / "build.log"
    run_logged(["make", f"-j{args.jobs}"], build_log, cwd=tree / "nuttx", env=env)
    binary = tree / "nuttx/nuttx.bin"
    if binary.stat().st_size + 0x2000 > 0x400000:
        raise RuntimeError("Image overlaps /data at 0x400000; refusing to package")
    symbols = subprocess.check_output([str(args.toolchain / "riscv32-esp-elf-nm"),
                                       str(tree / "nuttx/nuttx")], text=True)
    for symbol in required_symbol_names(args.variant, args.c6_desktop):
        if not any(line.endswith(" " + symbol) for line in symbols.splitlines()):
            raise RuntimeError(f"Missing final ELF symbol: {symbol}")
    for name, target in (("nuttx", "nuttx.elf"), ("nuttx.bin", "nuttx.bin"),
                         (".config", "resolved.config"), ("nuttx.map", "nuttx.map")):
        path = tree / "nuttx" / name
        if path.is_file():
            shutil.copy2(path, output / target)
    metadata = json.loads(marker.read_text())
    metadata.update(status="integration-candidate-offline-selftest-not-board-tested",
                    flash_offset="0x2000", data_partition="0x400000",
                    c6_desktop=args.c6_desktop,
                    binary_size=binary.stat().st_size,
                    sha256={name: hashlib.sha256((output / name).read_bytes()).hexdigest()
                            for name in ("nuttx.bin", "nuttx.elf", "resolved.config")})
    (output / "BUILD-METADATA.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(f"PASS: full integration candidate built: {output}; no board/online acceptance")


if __name__ == "__main__":
    main()
