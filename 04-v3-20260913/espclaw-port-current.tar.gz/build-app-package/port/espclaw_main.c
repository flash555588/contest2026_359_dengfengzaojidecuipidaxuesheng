/* SPDX-License-Identifier: Apache-2.0 */
#include "claw_core.h"
#include "claw_version.h"
#include "freertos/task.h"
#include <pthread.h>
#include <stdio.h>
#include <string.h>

/* Keep ownership if stop times out; the next invocation retries cleanup. */
static pthread_mutex_t command_lock = PTHREAD_MUTEX_INITIALIZER;
static claw_core_handle_t retained_core;

int espclaw_main(int argc, char **argv)
{
    if (argc != 2 || strcmp(argv[1], "selftest")) {
        puts("Usage: espclaw selftest (offline core lifecycle; no model configured)");
        return 1;
    }
    if (pthread_mutex_trylock(&command_lock)) {
        fputs("espclaw: another command is running\n", stderr);
        return 1;
    }
    int result = 1;
    esp_err_t err;
    if (retained_core) {
        err = claw_core_destroy(retained_core);
        if (err != ESP_OK) goto done;
        retained_core = NULL;
    }
    claw_core_config_t config = {
        .system_prompt = "Offline firmware lifecycle check",
        .task_stack_size = 32768,
        .task_core = tskNO_AFFINITY,
        .request_queue_len = 1,
        .response_queue_len = 1,
        .max_tool_iterations = 1,
    };
    err = claw_core_create(&config, &retained_core);
    if (err != ESP_OK) goto done;
    err = claw_core_start(retained_core);
    if (err == ESP_OK) {
        claw_core_request_t request = {
            .request_id = 1, .session_id = "offline-selftest", .user_text = "status"
        };
        claw_core_response_t response = {0};
        err = claw_core_submit(retained_core, &request, 1000);
        if (err == ESP_OK) err = claw_core_receive_for(retained_core, 1, &response, 3000);
        if (err == ESP_OK && response.request_id == 1 &&
            response.status == CLAW_CORE_RESPONSE_STATUS_OK && response.text &&
            strstr(response.text, "not configured")) result = 0;
        claw_core_response_free(&response);
    }
    esp_err_t cleanup = claw_core_destroy(retained_core);
    if (cleanup == ESP_OK) retained_core = NULL;
    else { result = 1; err = cleanup; }
done:
    if (!result) printf("ESP-Claw %s: offline core selftest PASS; network/model not tested\n",
                        claw_get_version());
    else fprintf(stderr, "espclaw: selftest failed (code %d, cleanup pending %s)\n",
                 err, retained_core ? "yes" : "no");
    pthread_mutex_unlock(&command_lock);
    return result;
}
