
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/drivers/everest/library/Hacl_Curve25519_joined.c" "tf-psa-crypto/drivers/everest/CMakeFiles/everest.dir/library/Hacl_Curve25519_joined.c.o" "gcc" "tf-psa-crypto/drivers/everest/CMakeFiles/everest.dir/library/Hacl_Curve25519_joined.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/drivers/everest/library/everest.c" "tf-psa-crypto/drivers/everest/CMakeFiles/everest.dir/library/everest.c.o" "gcc" "tf-psa-crypto/drivers/everest/CMakeFiles/everest.dir/library/everest.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/drivers/everest/library/x25519.c" "tf-psa-crypto/drivers/everest/CMakeFiles/everest.dir/library/x25519.c.o" "gcc" "tf-psa-crypto/drivers/everest/CMakeFiles/everest.dir/library/x25519.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
