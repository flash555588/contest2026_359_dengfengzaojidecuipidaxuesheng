#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "TF-PSA-Crypto::tfpsacrypto" for configuration "Release"
set_property(TARGET TF-PSA-Crypto::tfpsacrypto APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(TF-PSA-Crypto::tfpsacrypto PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libtfpsacrypto.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS TF-PSA-Crypto::tfpsacrypto )
list(APPEND _IMPORT_CHECK_FILES_FOR_TF-PSA-Crypto::tfpsacrypto "${_IMPORT_PREFIX}/lib/libtfpsacrypto.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
