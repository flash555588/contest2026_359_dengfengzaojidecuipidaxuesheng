
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/core/psa_crypto.c" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/psa_crypto.c.o" "gcc" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/psa_crypto.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/core/psa_crypto_client.c" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/psa_crypto_client.c.o" "gcc" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/psa_crypto_client.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/core/psa_crypto_driver_wrappers_no_static.c" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/psa_crypto_driver_wrappers_no_static.c.o" "gcc" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/psa_crypto_driver_wrappers_no_static.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/core/psa_crypto_slot_management.c" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/psa_crypto_slot_management.c.o" "gcc" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/psa_crypto_slot_management.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/core/psa_crypto_storage.c" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/psa_crypto_storage.c.o" "gcc" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/psa_crypto_storage.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/core/psa_its_file.c" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/psa_its_file.c.o" "gcc" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/psa_its_file.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/core/tf_psa_crypto_config.c" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/tf_psa_crypto_config.c.o" "gcc" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/tf_psa_crypto_config.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/core/tf_psa_crypto_version.c" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/tf_psa_crypto_version.c.o" "gcc" "tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/tf_psa_crypto_version.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-tls-host/tf-psa-crypto/drivers/builtin/CMakeFiles/builtin.dir/DependInfo.cmake"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-tls-host/tf-psa-crypto/drivers/everest/CMakeFiles/everest.dir/DependInfo.cmake"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-tls-host/tf-psa-crypto/drivers/p256-m/CMakeFiles/p256m.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
