# Install script for directory: /home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr/local")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set default install directory permissions.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/psa" TYPE FILE PERMISSIONS OWNER_READ OWNER_WRITE GROUP_READ WORLD_READ FILES
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_adjust_auto_enabled.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_adjust_config_dependencies.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_adjust_config_derived.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_adjust_config_key_pair_types.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_adjust_config_synonyms.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_builtin_composites.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_builtin_key_derivation.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_builtin_primitives.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_compat.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_config.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_driver_common.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_driver_contexts_composites.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_driver_contexts_key_derivation.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_driver_contexts_primitives.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_driver_random.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_extra.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_platform.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_sizes.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_struct.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_types.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/psa/crypto_values.h"
    )
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/tf-psa-crypto" TYPE FILE PERMISSIONS OWNER_READ OWNER_WRITE GROUP_READ WORLD_READ FILES
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/tf-psa-crypto/build_info.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/tf-psa-crypto/version.h"
    )
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/mbedtls" TYPE FILE PERMISSIONS OWNER_READ OWNER_WRITE GROUP_READ WORLD_READ FILES
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/../drivers/builtin/include/mbedtls/config_adjust_legacy_crypto.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/../drivers/builtin/include/mbedtls/private_access.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/asn1.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/asn1write.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/base64.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/compat-3-crypto.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/constant_time.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/lms.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/md.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/memory_buffer_alloc.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/nist_kw.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/pem.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/pk.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/platform.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/platform_time.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/platform_util.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/psa_util.h"
    "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/tf-psa-crypto/include/mbedtls/threading.h"
    )
endif()

