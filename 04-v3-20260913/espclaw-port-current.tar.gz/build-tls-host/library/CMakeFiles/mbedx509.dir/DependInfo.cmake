
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/library/error.c" "library/CMakeFiles/mbedx509.dir/error.c.o" "gcc" "library/CMakeFiles/mbedx509.dir/error.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/library/mbedtls_config.c" "library/CMakeFiles/mbedx509.dir/mbedtls_config.c.o" "gcc" "library/CMakeFiles/mbedx509.dir/mbedtls_config.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/library/pkcs7.c" "library/CMakeFiles/mbedx509.dir/pkcs7.c.o" "gcc" "library/CMakeFiles/mbedx509.dir/pkcs7.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/library/x509.c" "library/CMakeFiles/mbedx509.dir/x509.c.o" "gcc" "library/CMakeFiles/mbedx509.dir/x509.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/library/x509_create.c" "library/CMakeFiles/mbedx509.dir/x509_create.c.o" "gcc" "library/CMakeFiles/mbedx509.dir/x509_create.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/library/x509_crl.c" "library/CMakeFiles/mbedx509.dir/x509_crl.c.o" "gcc" "library/CMakeFiles/mbedx509.dir/x509_crl.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/library/x509_crt.c" "library/CMakeFiles/mbedx509.dir/x509_crt.c.o" "gcc" "library/CMakeFiles/mbedx509.dir/x509_crt.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/library/x509_csr.c" "library/CMakeFiles/mbedx509.dir/x509_csr.c.o" "gcc" "library/CMakeFiles/mbedx509.dir/x509_csr.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/library/x509_oid.c" "library/CMakeFiles/mbedx509.dir/x509_oid.c.o" "gcc" "library/CMakeFiles/mbedx509.dir/x509_oid.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/library/x509write.c" "library/CMakeFiles/mbedx509.dir/x509write.c.o" "gcc" "library/CMakeFiles/mbedx509.dir/x509write.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/library/x509write_crt.c" "library/CMakeFiles/mbedx509.dir/x509write_crt.c.o" "gcc" "library/CMakeFiles/mbedx509.dir/x509write_crt.c.o.d"
  "/home/flash/terminal-desktop-build-20260909/nxtmpdir/esp-hal-3rdparty/components/mbedtls/mbedtls/library/x509write_csr.c" "library/CMakeFiles/mbedx509.dir/x509write_csr.c.o" "gcc" "library/CMakeFiles/mbedx509.dir/x509write_csr.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-tls-host/tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/DependInfo.cmake"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-tls-host/tf-psa-crypto/drivers/builtin/CMakeFiles/builtin.dir/DependInfo.cmake"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-tls-host/tf-psa-crypto/drivers/everest/CMakeFiles/everest.dir/DependInfo.cmake"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-tls-host/tf-psa-crypto/drivers/p256-m/CMakeFiles/p256m.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
