
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/tests/test_mutex.c" "CMakeFiles/test_mutex.dir/tests/test_mutex.c.o" "gcc" "CMakeFiles/test_mutex.dir/tests/test_mutex.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-host/CMakeFiles/claw_posix_queue.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
