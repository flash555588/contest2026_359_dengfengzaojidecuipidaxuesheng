file(REMOVE_RECURSE
  "CMakeFiles/test_mutex.dir/tests/test_mutex.c.o"
  "CMakeFiles/test_mutex.dir/tests/test_mutex.c.o.d"
  "test_mutex"
  "test_mutex.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/test_mutex.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
