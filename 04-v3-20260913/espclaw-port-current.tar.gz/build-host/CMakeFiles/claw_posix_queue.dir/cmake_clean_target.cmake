file(REMOVE_RECURSE
  "libclaw_posix_queue.a"
)
