# Empty dependencies file for claw_posix_queue.
# This may be replaced when dependencies are built.
