
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/src/mutex.c" "CMakeFiles/claw_posix_queue.dir/src/mutex.c.o" "gcc" "CMakeFiles/claw_posix_queue.dir/src/mutex.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/src/queue.c" "CMakeFiles/claw_posix_queue.dir/src/queue.c.o" "gcc" "CMakeFiles/claw_posix_queue.dir/src/queue.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/src/task.c" "CMakeFiles/claw_posix_queue.dir/src/task.c.o" "gcc" "CMakeFiles/claw_posix_queue.dir/src/task.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
