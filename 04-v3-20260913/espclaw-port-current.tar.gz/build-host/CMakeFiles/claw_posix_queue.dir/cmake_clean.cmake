file(REMOVE_RECURSE
  "CMakeFiles/claw_posix_queue.dir/src/mutex.c.o"
  "CMakeFiles/claw_posix_queue.dir/src/mutex.c.o.d"
  "CMakeFiles/claw_posix_queue.dir/src/queue.c.o"
  "CMakeFiles/claw_posix_queue.dir/src/queue.c.o.d"
  "CMakeFiles/claw_posix_queue.dir/src/task.c.o"
  "CMakeFiles/claw_posix_queue.dir/src/task.c.o.d"
  "libclaw_posix_queue.a"
  "libclaw_posix_queue.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/claw_posix_queue.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
