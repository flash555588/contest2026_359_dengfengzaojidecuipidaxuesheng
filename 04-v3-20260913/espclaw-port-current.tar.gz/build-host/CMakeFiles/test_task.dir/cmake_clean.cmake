file(REMOVE_RECURSE
  "CMakeFiles/test_task.dir/tests/test_task.c.o"
  "CMakeFiles/test_task.dir/tests/test_task.c.o.d"
  "test_task"
  "test_task.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/test_task.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
