file(REMOVE_RECURSE
  "CMakeFiles/test_connect.dir/tests/test_connect.c.o"
  "CMakeFiles/test_connect.dir/tests/test_connect.c.o.d"
  "test_connect"
  "test_connect.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/test_connect.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
