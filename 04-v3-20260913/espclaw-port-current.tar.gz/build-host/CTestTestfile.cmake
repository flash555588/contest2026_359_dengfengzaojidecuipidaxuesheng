# CMake generated Testfile for 
# Source directory: /mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port
# Build directory: /mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-host
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(queue "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-host/test_queue")
set_tests_properties(queue PROPERTIES  TIMEOUT "20" _BACKTRACE_TRIPLES "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/CMakeLists.txt;14;add_test;/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/CMakeLists.txt;0;")
add_test(mutex "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-host/test_mutex")
set_tests_properties(mutex PROPERTIES  TIMEOUT "20" _BACKTRACE_TRIPLES "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/CMakeLists.txt;19;add_test;/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/CMakeLists.txt;0;")
add_test(task "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-host/test_task")
set_tests_properties(task PROPERTIES  TIMEOUT "20" _BACKTRACE_TRIPLES "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/CMakeLists.txt;24;add_test;/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/CMakeLists.txt;0;")
add_test(connect "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-host/test_connect")
set_tests_properties(connect PROPERTIES  TIMEOUT "20" _BACKTRACE_TRIPLES "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/CMakeLists.txt;29;add_test;/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/CMakeLists.txt;0;")
