
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/debug.c" "library/CMakeFiles/mbedtls.dir/debug.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/debug.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/mps_reader.c" "library/CMakeFiles/mbedtls.dir/mps_reader.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/mps_reader.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/mps_trace.c" "library/CMakeFiles/mbedtls.dir/mps_trace.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/mps_trace.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/net_sockets.c" "library/CMakeFiles/mbedtls.dir/net_sockets.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/net_sockets.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_cache.c" "library/CMakeFiles/mbedtls.dir/ssl_cache.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_cache.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_ciphersuites.c" "library/CMakeFiles/mbedtls.dir/ssl_ciphersuites.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_ciphersuites.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_client.c" "library/CMakeFiles/mbedtls.dir/ssl_client.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_client.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_cookie.c" "library/CMakeFiles/mbedtls.dir/ssl_cookie.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_cookie.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-tls-official/library/ssl_debug_helpers_generated.c" "library/CMakeFiles/mbedtls.dir/ssl_debug_helpers_generated.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_debug_helpers_generated.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_msg.c" "library/CMakeFiles/mbedtls.dir/ssl_msg.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_msg.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_ticket.c" "library/CMakeFiles/mbedtls.dir/ssl_ticket.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_ticket.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_tls.c" "library/CMakeFiles/mbedtls.dir/ssl_tls.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_tls.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_tls12_client.c" "library/CMakeFiles/mbedtls.dir/ssl_tls12_client.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_tls12_client.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_tls12_server.c" "library/CMakeFiles/mbedtls.dir/ssl_tls12_server.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_tls12_server.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_tls13_client.c" "library/CMakeFiles/mbedtls.dir/ssl_tls13_client.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_tls13_client.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_tls13_generic.c" "library/CMakeFiles/mbedtls.dir/ssl_tls13_generic.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_tls13_generic.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_tls13_keys.c" "library/CMakeFiles/mbedtls.dir/ssl_tls13_keys.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_tls13_keys.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/ssl_tls13_server.c" "library/CMakeFiles/mbedtls.dir/ssl_tls13_server.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/ssl_tls13_server.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/timing.c" "library/CMakeFiles/mbedtls.dir/timing.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/timing.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/library/version.c" "library/CMakeFiles/mbedtls.dir/version.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/version.c.o.d"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-tls-official/library/version_features.c" "library/CMakeFiles/mbedtls.dir/version_features.c.o" "gcc" "library/CMakeFiles/mbedtls.dir/version_features.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-tls-official/library/CMakeFiles/mbedx509.dir/DependInfo.cmake"
  "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/espclaw-port/build-tls-official/tf-psa-crypto/core/CMakeFiles/tfpsacrypto.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
