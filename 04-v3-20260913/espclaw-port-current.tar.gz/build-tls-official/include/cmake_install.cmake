# Install script for directory: /mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr/local")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set default install directory permissions.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/mbedtls" TYPE FILE PERMISSIONS OWNER_READ OWNER_WRITE GROUP_READ WORLD_READ FILES
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/build_info.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/debug.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/error.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/mbedtls_config.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/net_sockets.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/oid.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/pkcs7.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/ssl.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/ssl_cache.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/ssl_ciphersuites.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/ssl_cookie.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/ssl_ticket.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/timing.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/version.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/x509.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/x509_crl.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/x509_crt.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/x509_csr.h"
    )
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/mbedtls/private" TYPE FILE PERMISSIONS OWNER_READ OWNER_WRITE GROUP_READ WORLD_READ FILES
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/private/config_adjust_ssl.h"
    "/mnt/c/Users/flash/Desktop/新建文件夹 (2)/vlae/upstream/mbedtls-4.0.0/include/mbedtls/private/config_adjust_x509.h"
    )
endif()

