Paper/grain/scan textures are generated deterministically by the original renderer. No external image download is required.
