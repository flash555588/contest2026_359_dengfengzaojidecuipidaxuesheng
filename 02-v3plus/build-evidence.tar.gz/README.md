# Project ESP32-P4 v3.0+ candidates

Built from the user's contest project commit 10bc10d4aed0674e5f75795bdd488b68406c84a7 and its complete 27-patch overlay, not an unmodified streetartist firmware.
NuttX base: 2f1387d56eb04ad2599baca58a3fa2380cdaaedb.
Apps base: 88827afd368d4bbb4802b96ed44d9582f85b2f92.
Build trees: /home/flash/esp32p4-v3plus-isolated-20260906/{desktop,nsh}.

## Firmware

desktop/nuttx-v3x-desktop-OFFLINE-NOT-QUALIFIED.bin is the desktop candidate with LVGL, QuickJS, LCD, touch, SMP and requested 80MHz PSRAM. CSI is disabled.
nsh/nuttx-v3x-nsh-OFFLINE-NOT-QUALIFIED.bin is the single-core diagnostic candidate without PSRAM, LCD, touch or CSI.
Both use USB Serial/JTAG console, CPU 400MHz, Simple Boot and image revision bounds 300-399. Flash 4MB/DIO/80MHz remains a candidate assumption, not a measurement of the recipient's board. These are not v0/v1 images, nor a promise of compatibility with all future silicon.

## v3.0 fixes

v30-linker.patch expands the unavailable ALIGNED_SYMBOL linker macro into equivalent ALIGN/ABSOLUTE statements and adds the existing pinned HAL p4_rev3_mspi_workaround.S to GNU Make with forced symbol inclusion. No HAL assembly was rewritten.
The workaround is for MSPI recovery after deep-sleep wakeup; inclusion does not establish cold-boot success or power-management acceptance.
Both final ELF files contain 216 bytes of executable workaround at 0x50108000, ending at 0x501080d8, inside the configured 256-byte reservation.

## Validation

Both builds completed compilation, linking and esptool 4.8.1 packaging with Espressif GCC 15.2.0.
Real resolved configuration, v3 headers/ECO5 ROM/linker selection, workaround symbol, image header, RAM XOR and file SHA256 checks passed. Run verify.sh in the build environment to repeat these checks.
Build logs, ELF, nm/readelf output, configurations, source diffs and metadata are included per profile. The helper validates the RAM image checksum, not mapped-trailer semantics or hardware ROM execution.
Dependencies were freshly checked out from pinned local Git objects and the project HAL patches explicitly applied; old object files and binaries were not copied. No network fetch, flash command or serial access was performed.

## Hardware status

NOT HARDWARE QUALIFIED. Actual boot on the recipient's board has not been tested. Board power, Flash/PSRAM identity and console connector must match before a boot test. The existing v3 single-page framebuffer and HAL task-affinity limitations remain. Camera functionality is not included in these candidates.
Existing repositories and the previous v3.1+ deliverables were left unchanged.
