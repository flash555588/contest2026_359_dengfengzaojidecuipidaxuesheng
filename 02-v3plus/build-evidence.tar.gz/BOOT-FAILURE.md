# Withdrawn: ECO7 boot failure

The desktop candidate nuttx-v3x-desktop-OFFLINE-NOT-QUALIFIED.bin is withdrawn from boot testing pending investigation.
Whole-file SHA256: ca42f7bff8186658fb63cf5f6e47418b843288c2e7caa393f5c914ca42eda6ff.

User-provided log identifies ESP-ROM esp32p4-eco7-20260109 and repeated HP_SYS_HP_WDT_RESET after image loading. First apparent display success occurred when flashing after another working firmware; this does not establish a successful independent cold boot.

Verified locally against the delivered binary:

- All five ROM load addresses and lengths match the image.
- Header byte 23 is zero.
- RAM image including checksum ends at file offset 26928.
- SHA256 of bytes [0,26928) is d341c834d7f9b0f544f9f513b85f9725407534278b88e49816f841130b27f37f, exactly the ROM Calculated value.
- Bytes [26928,26960) are 00000000e0760000000000000000000000000000000000000000000000000000, exactly the ROM Expected value. These are trailer bytes, not an appended digest.

This demonstrates a digest/trailer interpretation mismatch on the observed ROM boot path. It does not establish whether this mismatch causes the watchdog reset; the ROM explicitly attempts to continue. No claim is made that header flag behavior is understood for all ECO7 parts.

Next investigation must examine image generation and mapped trailer offsets together, and the startup initialization skipped by the project's HAL Simple Boot patch. Do not merely append a digest or remove watchdog/version checks. Cold boot and repeated resets must be validated separately from warm-state flashing.

No corrective firmware has yet passed target-board validation. The original build-only checks were insufficient to establish ROM compatibility.
