#!/usr/bin/env bash
set -euo pipefail
profile=${1:?nsh or desktop}
case "$profile" in nsh|desktop) ;; *) exit 2 ;; esac
export PATH=/home/flash/.local/bin:/home/flash/vela-p4/riscv32-esp-elf/bin:/usr/local/bin:/usr/bin:/bin
export CROSSDEV=/home/flash/vela-p4/riscv32-esp-elf/bin/riscv32-esp-elf-
out=$(cd "$(dirname "$0")" && pwd)
root=/home/flash/esp32p4-v3plus-isolated-20260906
work="$root/$profile"
dest="$out/$profile"
mkdir -p "$dest"
exec > >(tee "$dest/pipeline.log") 2>&1
cache=/home/flash/openvela-contest359-clean
halcache="$cache/nuttx/arch/risc-v/src/esp32p4/esp-hal-3rdparty"
export GIT_CONFIG_COUNT=3 GIT_CONFIG_KEY_0=protocol.allow GIT_CONFIG_VALUE_0=never
export GIT_CONFIG_KEY_1=protocol.file.allow GIT_CONFIG_VALUE_1=always
export GIT_CONFIG_KEY_2="url.$halcache/components/mbedtls/mbedtls.insteadOf"
export GIT_CONFIG_VALUE_2=/home/flash/openvela-contest359-clean/nuttx/arch/risc-v/src/espressif/mbedtls.git
unset USE_NXTMPDIR_ESP_REPO_DIRECTLY || true
"${CROSSDEV}gcc" -dumpfullversion | grep -qx 15.2.0
python3 -c 'import esptool; assert esptool.__version__ == "4.8.1"'
cd "$work"
config="nuttx/boards/risc-v/esp32p4/esp32p4-function-ev-board/configs/audit-$profile/defconfig"
python3 "$out/p4_audit.py" prepare --nuttx nuttx --apps apps \
  --base project/configs/esp32p4-function-ev-board/desktop-v3.2/defconfig \
  --profile "$profile" --output "$config"
cp "$config" "$config.evidence.json" "$dest/"
cp overlay.log "$dest/"
cd nuttx
for patched in boards/risc-v/esp32p4/common/scripts/esp32p4_sections.rev3.ld arch/risc-v/src/esp32p4/hal_esp32p4.mk; do
if git apply --include="$patched" --check "$out/v30-linker.patch" 2>/dev/null; then
  git apply --include="$patched" "$out/v30-linker.patch"
else
  git apply --include="$patched" --reverse --check "$out/v30-linker.patch"
fi
done
if [[ ! -f .config ]]; then
  ./tools/configure.sh -E -S -l -a ../apps "esp32p4-function-ev-board:audit-$profile"
fi
make olddefconfig
python3 "$out/p4_audit.py" check-resolved --config .config --profile "$profile"
cp .config "$dest/resolved.config"
# Complete a previously interrupted local HAL submodule/patch stage.
hal="$work/nuttx/arch/risc-v/src/esp32p4/esp-hal-3rdparty"
if [[ ! -f "$dest/hal-ready" ]]; then
if [[ -e "$hal" ]]; then
  case "$(realpath "$hal")" in
    "$work/nuttx/arch/risc-v/src/esp32p4/esp-hal-3rdparty"|"$work/nxtmpdir/esp-hal-3rdparty") ;;
    *) exit 2 ;;
  esac
  mv "$hal" "$hal.failed-$(date +%s)"
fi
git clone --quiet --no-hardlinks --no-checkout "$halcache" "$hal"
git -C "$hal" checkout --quiet --detach 78c092909fca38d1e2ccf767b5eff66bddc5c789
git clone --quiet --no-hardlinks --no-checkout "$halcache/components/mbedtls/mbedtls" "$hal/components/mbedtls/mbedtls"
git -C "$hal/components/mbedtls/mbedtls" checkout --quiet --detach 582ff482038db6e4010dbf6f943d97b05ad06ea5
if [[ -d "$hal" ]]; then
  test "$(git -C "$hal" rev-parse HEAD)" = 78c092909fca38d1e2ccf767b5eff66bddc5c789
  patches=("$work/nuttx/arch/risc-v/src/esp32p4/patches/esp-hal-3rdparty/"*.patch)
  if git -C "$hal" apply --check "${patches[@]}"; then
    git -C "$hal" apply "${patches[@]}"
  else
    git -C "$hal" apply --reverse --check "${patches[@]}"
  fi
fi
touch "$dest/hal-ready"
fi
make -j4 V=1 CROSSDEV="$CROSSDEV" ESP_HAL_3RDPARTY_URL="$halcache" \
  DISABLE_GIT_DEPTH=1 DOWNLOAD=false CURL=false WGET=false > "$dest/build.log" 2>&1
hal="$work/nuttx/arch/risc-v/src/esp32p4/esp-hal-3rdparty"
test "$(git -C "$hal" rev-parse HEAD)" = 78c092909fca38d1e2ccf767b5eff66bddc5c789
test "$(git -C "$hal/components/mbedtls/mbedtls" rev-parse HEAD)" = 582ff482038db6e4010dbf6f943d97b05ad06ea5
cp nuttx "$dest/nuttx.elf"
"${CROSSDEV}readelf" -h -l -S nuttx > "$dest/readelf.txt"
"${CROSSDEV}nm" -n nuttx > "$dest/nm.txt"
python3 -m esptool --chip esp32p4 elf2image --ram-only-header \
  --flash_size 4MB --flash_mode dio --flash_freq 80m \
  --min-rev-full 300 --max-rev-full 399 \
  -o "$dest/nuttx-v3x-$profile-OFFLINE-NOT-QUALIFIED.bin" nuttx
python3 "$out/p4_audit.py" image --expect-candidate \
  "$dest/nuttx-v3x-$profile-OFFLINE-NOT-QUALIFIED.bin" > "$dest/image-header.json"
git diff --binary > "$dest/nuttx-overlay.diff"
git -C ../apps diff --binary > "$dest/apps-overlay.diff"
git -C "$hal" diff --binary > "$dest/hal-applied.diff"
git -C ../apps/graphics/lvgl/lvgl diff --binary > "$dest/lvgl-applied.diff"
{
  printf 'status=OFFLINE_ONLY_NOT_HARDWARE_QUALIFIED\nprofile=%s\nworkspace=%s\n' "$profile" "$work"
  date -Is
  "${CROSSDEV}gcc" --version
  sha256sum "${CROSSDEV}gcc"
  python3 -m esptool version
  for repo in ../project . ../apps "$hal" "$hal/components/mbedtls/mbedtls" ../apps/graphics/lvgl/lvgl; do
    printf '\nrepository=%s\n' "$repo"
    git -C "$repo" rev-parse HEAD
  done
} > "$dest/BUILD-METADATA.txt"
cd "$dest"
sha256sum nuttx.elf *.bin resolved.config > SHA256SUMS
echo "SUCCESS: $dest"
