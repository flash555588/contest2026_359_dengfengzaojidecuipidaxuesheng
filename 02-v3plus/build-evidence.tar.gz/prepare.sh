#!/usr/bin/env bash
set -euo pipefail
export PATH=/home/flash/.local/bin:/home/flash/vela-p4/riscv32-esp-elf/bin:/usr/local/bin:/usr/bin:/bin
export GIT_CONFIG_COUNT=2 GIT_CONFIG_KEY_0=protocol.allow GIT_CONFIG_VALUE_0=never
export GIT_CONFIG_KEY_1=protocol.file.allow GIT_CONFIG_VALUE_1=always
out=$(cd "$(dirname "$0")" && pwd)
root=/home/flash/esp32p4-v3plus-isolated-20260906
cache=/home/flash/openvela-contest359-clean
mkdir "$root"
printf '%s\n' "$root" > "$out/build-root.txt"
test -f "$out/p4_audit.py"
clone_at() {
  git clone --quiet --no-hardlinks --no-checkout "$1" "$2"
  git -C "$2" checkout --quiet --detach "$3"
  test "$(git -C "$2" rev-parse HEAD)" = "$3"
  test -z "$(git -C "$2" status --porcelain)"
}
clone_at "$out/../contest2026_359_dengfengzaojidecuipidaxuesheng" "$root/project" 10bc10d4aed0674e5f75795bdd488b68406c84a7
for profile in nsh desktop; do
  work="$root/$profile"
  mkdir "$work"
  clone_at "$root/project" "$work/project" 10bc10d4aed0674e5f75795bdd488b68406c84a7
  clone_at "$cache/nuttx" "$work/nuttx" 2f1387d56eb04ad2599baca58a3fa2380cdaaedb
  clone_at "$cache/apps" "$work/apps" 88827afd368d4bbb4802b96ed44d9582f85b2f92
  bash "$work/project/tools/apply_final_overlays.sh" > "$work/overlay.log" 2>&1
  bash "$work/project/tools/apply_final_overlays.sh" >> "$work/overlay.log" 2>&1
  clone_at "$cache/apps/graphics/lvgl/lvgl" "$work/apps/graphics/lvgl/lvgl" 59a6b61c9580b65089010c5273f2fcdd6c4d2aae
  cp "$cache/apps/interpreters/quickjs/quickjs-6e2e68fd0896957f92eb6c242a2e048c1ef3cae0.zip" "$work/apps/interpreters/quickjs/"
  echo "Prepared $work"
done
