#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
readelf=/home/flash/vela-p4/riscv32-esp-elf/bin/riscv32-esp-elf-readelf
for profile in nsh desktop; do
  python3 p4_audit.py check-resolved --config "$profile/resolved.config" --profile "$profile"
  python3 p4_audit.py image --expect-candidate "$profile/nuttx-v3x-$profile-OFFLINE-NOT-QUALIFIED.bin" > "$profile/image-header.json"
  "$readelf" -SW "$profile/nuttx.elf" > "$profile/sections-wide.txt"
  grep -E '\.rtc\.p4_rev3_mspi_workaround .*PROGBITS' "$profile/sections-wide.txt"
  grep '_rtc_p4_rev3_mspi_workaround_' "$profile/nm.txt"
  grep -E ' [Tt] p4_rev3_mspi_workaround$' "$profile/nm.txt"
  grep -q 'hw_ver3' "$profile/build.log"
  grep -q 'rom.eco5' "$profile/build.log"
  grep -q 'esp32p4_sections.rev3.ld' "$profile/build.log"
  (cd "$profile" && sha256sum -c SHA256SUMS)
done
