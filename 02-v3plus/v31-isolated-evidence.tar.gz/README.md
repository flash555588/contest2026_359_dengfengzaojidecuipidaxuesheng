# ESP32-P4 v3.x Offline Candidates

Built on 2026-09-06 in Ubuntu-22.04 WSL. No device access or flashing was performed.
Status: BUILD AND IMAGE CHECKS PASSED; NOT HARDWARE QUALIFIED.

## Outputs

- `nsh/nuttx-v3x-nsh-OFFLINE-NOT-QUALIFIED.bin`: 227116 bytes; single core, no PSRAM, LCD, touch or CSI.
- `desktop/nuttx-v3x-desktop-OFFLINE-NOT-QUALIFIED.bin`: 3015068 bytes; dual core, LVGL/QuickJS, LCD and touch, PSRAM at requested 80 MHz; CSI disabled.
- Each directory includes ELF, resolved configuration, configuration evidence, verbose build log, readelf/nm output, source diffs, metadata and SHA256SUMS.

Both images use Simple Boot, CPU 400 MHz, USB Serial/JTAG console, image revision range 301-399, and candidate Flash settings 4MB/DIO/80MHz. This range excludes v3.0 and does not prove support for every later revision or an unidentified "v3.4" board. Flash settings are software assumptions, not measurements.

## Source Pins

Project: `10bc10d4aed0674e5f75795bdd488b68406c84a7`

NuttX: `2f1387d56eb04ad2599baca58a3fa2380cdaaedb`

Apps: `88827afd368d4bbb4802b96ed44d9582f85b2f92`

HAL: `78c092909fca38d1e2ccf767b5eff66bddc5c789`

mbedTLS: `582ff482038db6e4010dbf6f943d97b05ad06ea5`

LVGL: `59a6b61c9580b65089010c5273f2fcdd6c4d2aae`

Compiler: Espressif GCC 15.2.0. Image tool: esptool 4.8.1.

## Isolation and Verification

Build trees: `/home/flash/esp32p4-v3-isolated-20260906/{nsh,desktop}`.
Source objects were cloned locally without hardlinks; old compiler outputs were not copied.
The 27 project patches passed checksum, ordered application and repeat-application fingerprint checks.
Real Kconfig resolution and critical configuration checks passed for both profiles.
Actual build logs contain hw_ver3 headers, ECO5 ROM scripts and esp32p4_sections.rev3.ld.
Both images passed chip ID, revision bounds, Flash header settings and RAM XOR checks; hash_appended is zero.
The image helper does not validate mapped Flash trailer semantics, signatures or ROM execution.

## Adjustments to the Supplied Toolkit

Removed undefined legacy CONFIG_NSH_ARCHINIT from generated configurations. Its removal is recorded in configuration evidence; board late initialization remains enabled by the actual resolved configuration.
Used the installed Kconfiglib olddefconfig frontend instead of requiring the absent kconfig-conf executable.
Normal HAL fetching was attempted but failed on local relative submodule URLs and nxtmpdir Git metadata. Final builds use fresh, pinned local HAL and mbedTLS checkouts with the exact project HAL patches explicitly checked and applied. This is a documented deviation from the supplied normal-fetch-only procedure, not a validation of that procedure.
Git non-file transports and download commands were disabled. No credentials were saved.

## Remaining Limits

No board identity, voltage, memory BOM, ROM boot, PSRAM test, LCD timing, touch or SMP acceptance has been performed.
The v3 desktop path retains the existing single-page framebuffer limitation. HAL task affinity behavior was not repaired or hardware-tested.
These binaries must not be treated as qualified production firmware or as evidence of v3.4 hardware compatibility.
