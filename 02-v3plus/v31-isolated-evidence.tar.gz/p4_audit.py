#!/usr/bin/env python3
"""Offline-only helpers for the pinned contest359 ESP32-P4 source audit.

Not a flash utility, Kconfig interpreter, or hardware qualification test.
Run the real NuttX olddefconfig after prepare, then check-resolved.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import sys

SYMBOL = re.compile(r'^\s*(?:menuconfig|config)\s+([A-Za-z0-9_]+)\b')
ASSIGN = re.compile(r'^(CONFIG_[A-Za-z0-9_]+)=(.*)$')
UNSET = re.compile(r'^# (CONFIG_[A-Za-z0-9_]+) is not set$')
P = '10bc10d4aed0674e5f75795bdd488b68406c84a7'
N = '2f1387d56eb04ad2599baca58a3fa2380cdaaedb'
A = '88827afd368d4bbb4802b96ed44d9582f85b2f92'


def read_config(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        m = ASSIGN.match(line)
        if m:
            values[m[1]] = m[2]
        else:
            m = UNSET.match(line)
            if m:
                values[m[1]] = 'n'
    return values


def symbol_index(roots: list[Path]) -> dict[str, list[str]]:
    index: dict[str, list[str]] = {}
    for root in roots:
        root = root.resolve(strict=True)
        for directory, dirs, names in os.walk(root, followlinks=False):
            dirs[:] = [d for d in dirs if d not in {'.git', '.venv', 'build', '__pycache__'}]
            for name in names:
                if name != 'Kconfig' and not name.startswith('Kconfig.'):
                    continue
                path = Path(directory) / name
                if path.is_symlink():
                    continue
                for line_no, line in enumerate(path.read_text(encoding='utf-8', errors='replace').splitlines(), 1):
                    m = SYMBOL.match(line)
                    if m:
                        index.setdefault('CONFIG_' + m[1], []).append(str(path) + ':' + str(line_no))
    return index


def prepare(args: argparse.Namespace) -> None:
    config = read_config(args.base)
    removed = {}
    # These are stale standalone-copy settings, not new Kconfig options.
    for key in ('NSH_ARCHINIT', 'ESPRESSIF_I2C_PERIPH', 'INPUT_GT9XX_POLL',
                'ESPRESSIF_I2C1_SCLPIN', 'ESPRESSIF_I2C1_SDAPIN'):
        key = 'CONFIG_' + key
        if key in config:
            removed[key] = config.pop(key)
    updates = {
        'ESP32P4_SELECTS_REV_LESS_V3': 'n',
        'ESP32P4_REV_MIN_301': 'y',
        'ESPRESSIF_CPU_FREQ_400': 'y',
        'ESPRESSIF_SIMPLE_BOOT': 'y',
        'ESPRESSIF_FLASH_4M': 'y',
        'ESPRESSIF_FLASH_MODE_DIO': 'y',
        'ESPRESSIF_I2C1': 'n',
        'ESPRESSIF_I2C0': 'y',
        'ESPRESSIF_I2C0_SCLPIN': '8',
        'ESPRESSIF_I2C0_SDAPIN': '7',
        'INPUT_GT9XX_POLL_INTERVAL': '50',
        'SCHED_LPWORK': 'y',
        'ESPRESSIF_SPIRAM_SPEED_80M': 'y',
        'ESPRESSIF_MIPI_CSI': 'n',
        'ESPRESSIF_USBSERIAL': 'y',
        'ESPRESSIF_USBSERIAL_CONSOLE': 'y',
        'ESPRESSIF_UART0': 'n',
        'NET': 'y', 'NET_IPv4': 'y', 'NET_TCP': 'y',
        'NET_LOOPBACK': 'y', 'LIBC_NETDB': 'y',
        'NETDEVICES': 'y', 'NETDEV_LATEINIT': 'y', 'NET_SOCKOPTS': 'y',
    }
    if args.profile == 'nsh':
        updates.update({
            'INIT_ENTRYPOINT': '"nsh_main"',
            'SYSTEM_DESKTOP': 'n', 'GRAPHICS_LVGL': 'n',
            'INTERPRETERS_QUICKJS': 'n',
            'ESP32P4_FUNCTION_EV_BOARD_LCD': 'n',
            'ESP32P4_FUNCTION_EV_BOARD_TOUCHSCREEN': 'n',
            'ESPRESSIF_MIPI_DSI': 'n', 'INPUT_GT9XX': 'n',
            'ESPRESSIF_SPIRAM': 'n', 'SMP': 'n',
            'ESPRESSIF_I2C0': 'n', 'INPUT_GT9XX_POLL_INTERVAL': '0',
            'NET': 'n', 'NET_IPv4': 'n', 'NET_TCP': 'n',
            'NET_LOOPBACK': 'n', 'LIBC_NETDB': 'n',
            'NETDEVICES': 'n', 'NETDEV_LATEINIT': 'n', 'NET_SOCKOPTS': 'n',
        })
    config.update({'CONFIG_' + k: v for k, v in updates.items()})
    index = symbol_index([args.nuttx, args.apps])
    unknown = sorted(set(config) - set(index))
    evidence = {k: {'requested': v, 'definitions': index.get(k, [])} for k, v in sorted(config.items())}
    manifest = {
        'status': 'OFFLINE ONLY - NOT HARDWARE QUALIFIED',
        'profile': args.profile,
        'project_sha': P, 'nuttx_base': N, 'apps_base': A,
        'base_sha256': hashlib.sha256(args.base.read_bytes()).hexdigest(),
        'removed_stale_entries': removed,
        'unknown_symbols': unknown,
        'symbols': evidence,
        'limitations': [
            'Textual definition scan does not evaluate Kconfig dependencies.',
            'Run NuttX olddefconfig and check-resolved.',
            '4MB/DIO/80MHz is an offline candidate assumption, not a hardware identity.',
            'PSRAM 80MHz is a deliberately reduced initial test setting, not the frozen desktop default.',
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    evidence_path = args.output.with_suffix(args.output.suffix + '.evidence.json')
    evidence_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    if unknown:
        raise ValueError('Undefined Kconfig symbols; no defconfig emitted: ' + ', '.join(unknown) + '. See ' + str(evidence_path))
    lines = ['# OFFLINE CANDIDATE ONLY. Target identity and board power are not qualified.',
             '# Source base: P=' + P, '# Profile: ' + args.profile]
    for key, value in sorted(config.items()):
        lines.append('# ' + key + ' is not set' if value == 'n' else key + '=' + value)
    args.output.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('Wrote', args.output, 'and', evidence_path)


def check_resolved(args: argparse.Namespace) -> None:
    c = read_config(args.config)
    expected = {
        'ESP32P4_SELECTS_REV_LESS_V3': 'n',
        'ESP32P4_REV_MIN_301': 'y',
        'ESP32P4_REV_MIN_FULL': '301',
        'ESP32P4_REV_MAX_FULL': '399',
        'ESPRESSIF_CPU_FREQ_400': 'y',
        'ESPRESSIF_CPU_FREQ_MHZ': '400',
        'ESPRESSIF_SIMPLE_BOOT': 'y',
        'ESPRESSIF_FLASH_4M': 'y',
        'ESPRESSIF_FLASH_MODE_DIO': 'y',
        'ESPRESSIF_USBSERIAL': 'y',
        'ESPRESSIF_USBSERIAL_CONSOLE': 'y',
        'ESPRESSIF_UART0': 'n',
        'ESPRESSIF_MIPI_CSI': 'n',
    }
    if args.profile == 'desktop':
        expected.update({'ESPRESSIF_SPIRAM': 'y', 'ESPRESSIF_SPIRAM_SPEED_80M': 'y',
                         'SMP': 'y', 'SMP_NCPUS': '2',
                         'ESPRESSIF_I2C0': 'y', 'ESPRESSIF_I2C1': 'n',
                         'ESPRESSIF_I2C0_SCLPIN': '8', 'ESPRESSIF_I2C0_SDAPIN': '7',
                         'INPUT_GT9XX_POLL_INTERVAL': '50', 'SCHED_LPWORK': 'y',
                         'INIT_ENTRYPOINT': '"desktop_main"'})
    else:
        expected.update({'SMP': 'n', 'ESPRESSIF_SPIRAM': 'n',
                         'ESPRESSIF_MIPI_DSI': 'n', 'GRAPHICS_LVGL': 'n',
                         'SYSTEM_DESKTOP': 'n', 'INIT_ENTRYPOINT': '"nsh_main"'})
    failures = []
    for k, v in expected.items():
        key = 'CONFIG_' + k
        actual = c.get(key, 'n')
        if actual != v:
            failures.append(f'{key}: expected {v}, got {actual}')
    # Flash frequency is derived from real Kconfig; do not invent a choice symbol.
    freq = c.get('CONFIG_ESPRESSIF_FLASH_FREQ', '').strip('"').lower()
    if freq not in {'80m', '80'}:
        failures.append('CONFIG_ESPRESSIF_FLASH_FREQ is not 80m/80: ' + repr(freq))
    if failures:
        raise ValueError('Resolved configuration mismatch:\n' + '\n'.join(failures))
    print('Requested critical configuration values match. This is not a boot or electrical test.')


def inspect_image(path: Path) -> dict:
    data = path.read_bytes()
    if len(data) < 24 or data[0] != 0xE9:
        raise ValueError('Not an ESP image with a complete 24-byte header')
    count = data[1]
    if not 1 <= count <= 16:
        raise ValueError('Invalid segment count: ' + str(count))
    chip = struct.unpack_from('<H', data, 12)[0]
    minimum, maximum = struct.unpack_from('<HH', data, 15)
    segments = []
    offset, checksum = 24, 0xEF
    for number in range(count):
        if offset + 8 > len(data):
            raise ValueError('Truncated segment header')
        address, length = struct.unpack_from('<II', data, offset)
        offset += 8
        end = offset + length
        if end > len(data):
            raise ValueError('Truncated segment data')
        for value in data[offset:end]:
            checksum ^= value
        segments.append({'index': number, 'load_addr': hex(address), 'length': length, 'file_offset': offset})
        offset = end
    checksum_offset = ((offset + 1 + 15) // 16) * 16 - 1
    if checksum_offset >= len(data):
        raise ValueError('Missing image checksum')
    return {
        'file': str(path), 'bytes': len(data),
        'sha256_whole_file': hashlib.sha256(data).hexdigest(),
        'chip_id': chip, 'entrypoint': hex(struct.unpack_from('<I', data, 4)[0]),
        'segment_count_in_header': count, 'segments': segments,
        'flash_mode_byte': data[2], 'flash_size_nibble': data[3] >> 4,
        'flash_frequency_nibble': data[3] & 15,
        'min_revision_full': minimum, 'max_revision_full': maximum,
        'hash_appended_flag': data[23],
        'xor_checksum_offset': checksum_offset,
        'xor_checksum_computed': checksum, 'xor_checksum_stored': data[checksum_offset],
        'xor_checksum_valid': checksum == data[checksum_offset],
        'bytes_after_ram_image_checksum': len(data) - checksum_offset - 1,
        'limitations': 'Mapped flash trailer, ROM behavior, signature/security policy and hardware are not validated.',
    }


def image(args: argparse.Namespace) -> None:
    report = inspect_image(args.path)
    print(json.dumps(report, indent=2))
    if args.expect_candidate:
        expected = {'chip_id': 18, 'flash_mode_byte': 2, 'flash_size_nibble': 2,
                    'flash_frequency_nibble': 15, 'min_revision_full': 301,
                    'max_revision_full': 399, 'hash_appended_flag': 0,
                    'xor_checksum_valid': True}
        bad = [k for k, v in expected.items() if report[k] != v]
        if bad:
            raise ValueError('Not the specified offline Simple Boot candidate: ' + ', '.join(bad))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('prepare')
    p.add_argument('--nuttx', type=Path, required=True)
    p.add_argument('--apps', type=Path, required=True)
    p.add_argument('--base', type=Path, required=True)
    p.add_argument('--profile', choices=['desktop', 'nsh'], required=True)
    p.add_argument('--output', type=Path, required=True)
    p.set_defaults(func=prepare)
    p = sub.add_parser('check-resolved')
    p.add_argument('--config', type=Path, required=True)
    p.add_argument('--profile', choices=['desktop', 'nsh'], required=True)
    p.set_defaults(func=check_resolved)
    p = sub.add_parser('image')
    p.add_argument('path', type=Path)
    p.add_argument('--expect-candidate', action='store_true')
    p.set_defaults(func=image)
    args = parser.parse_args()
    try:
        args.func(args)
    except (OSError, ValueError) as error:
        print('STOP:', error, file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
